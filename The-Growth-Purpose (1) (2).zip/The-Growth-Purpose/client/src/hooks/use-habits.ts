import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Habit, InsertHabit, HabitLog } from "@shared/schema";

export function useHabits() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const habitsQuery = useQuery<Habit[]>({
    queryKey: ["/api/habits"],
  });

  const createHabitMutation = useMutation({
    mutationFn: async (habitData: Omit<InsertHabit, "userId">) => {
      return apiRequest("POST", "/api/habits", habitData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habits"] });
      toast({
        title: "Habit created! 🎉",
        description: "Your new habit has been added to your routine.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create habit",
        variant: "destructive",
      });
    },
  });

  const updateHabitMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<InsertHabit> }) => {
      return apiRequest("PATCH", `/api/habits/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habits"] });
      toast({
        title: "Habit updated! ✅",
        description: "Your habit has been successfully updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update habit",
        variant: "destructive",
      });
    },
  });

  const deleteHabitMutation = useMutation({
    mutationFn: async (habitId: number) => {
      return apiRequest("DELETE", `/api/habits/${habitId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habits"] });
      toast({
        title: "Habit removed",
        description: "The habit has been removed from your routine.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete habit",
        variant: "destructive",
      });
    },
  });

  return {
    habits: habitsQuery.data || [],
    isLoading: habitsQuery.isLoading,
    error: habitsQuery.error,
    createHabit: createHabitMutation.mutate,
    updateHabit: updateHabitMutation.mutate,
    deleteHabit: deleteHabitMutation.mutate,
    isCreating: createHabitMutation.isPending,
    isUpdating: updateHabitMutation.isPending,
    isDeleting: deleteHabitMutation.isPending,
  };
}

export function useHabitLogs(habitId?: number) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const today = new Date().toISOString().split('T')[0];

  const habitLogsQuery = useQuery<HabitLog[]>({
    queryKey: ["/api/habit-logs", habitId],
    enabled: !!habitId,
  });

  const todayLogsQuery = useQuery<HabitLog[]>({
    queryKey: ["/api/habit-logs/user", today],
  });

  const logHabitMutation = useMutation({
    mutationFn: async ({ habitId, date, count = 1 }: { habitId: number; date: string; count?: number }) => {
      return apiRequest("POST", "/api/habit-logs", { habitId, date, count });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habit-logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/habits"] });
      toast({
        title: "Great job! 🎉",
        description: "Habit logged successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to log habit",
        variant: "destructive",
      });
    },
  });

  return {
    habitLogs: habitLogsQuery.data || [],
    todayLogs: todayLogsQuery.data || [],
    isLoading: habitLogsQuery.isLoading || todayLogsQuery.isLoading,
    logHabit: logHabitMutation.mutate,
    isLogging: logHabitMutation.isPending,
  };
}

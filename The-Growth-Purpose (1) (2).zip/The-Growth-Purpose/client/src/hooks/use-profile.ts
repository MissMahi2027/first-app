import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User, InsertUser, UserPreferences, InsertUserPreferences } from "@shared/schema";

export function useProfile() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const userQuery = useQuery<User>({
    queryKey: ["/api/user"],
  });

  const preferencesQuery = useQuery<UserPreferences>({
    queryKey: ["/api/preferences"],
  });

  const updateUserMutation = useMutation({
    mutationFn: async (updates: Partial<InsertUser>) => {
      return apiRequest("PATCH", "/api/user", updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Profile updated! ✅",
        description: "Your profile has been successfully updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const updatePreferencesMutation = useMutation({
    mutationFn: async (updates: Partial<InsertUserPreferences>) => {
      return apiRequest("PATCH", "/api/preferences", updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/preferences"] });
      toast({
        title: "Preferences updated! ⚙️",
        description: "Your preferences have been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update preferences",
        variant: "destructive",
      });
    },
  });

  return {
    user: userQuery.data,
    preferences: preferencesQuery.data,
    isLoading: userQuery.isLoading || preferencesQuery.isLoading,
    updateUser: updateUserMutation.mutate,
    updatePreferences: updatePreferencesMutation.mutate,
    isUpdatingUser: updateUserMutation.isPending,
    isUpdatingPreferences: updatePreferencesMutation.isPending,
  };
}

import { useState, useEffect, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PomodoroSettings {
  workTime: number; // minutes
  breakTime: number; // minutes
  longBreakTime: number; // minutes
  sessionsUntilLongBreak: number;
}

const DEFAULT_SETTINGS: PomodoroSettings = {
  workTime: 25,
  breakTime: 5,
  longBreakTime: 15,
  sessionsUntilLongBreak: 4,
};

export function usePomodoroTimer() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [settings] = useState<PomodoroSettings>(DEFAULT_SETTINGS);
  const [timeLeft, setTimeLeft] = useState(settings.workTime * 60);
  const [isActive, setIsActive] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const [sessionsCompleted, setSessionsCompleted] = useState(0);
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null);
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: { duration: number; category?: string }) => {
      return apiRequest("POST", "/api/pomodoro", sessionData);
    },
    onSuccess: (data: any) => {
      setCurrentSessionId(data.id);
    },
  });

  const completeSessionMutation = useMutation({
    mutationFn: async (sessionId: number) => {
      return apiRequest("PATCH", `/api/pomodoro/${sessionId}`, { completed: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pomodoro"] });
    },
  });

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((time) => time - 1);
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isActive, timeLeft]);

  useEffect(() => {
    if (timeLeft === 0) {
      handleTimerComplete();
    }
  }, [timeLeft]);

  const handleTimerComplete = () => {
    setIsActive(false);

    if (!isBreak) {
      // Work session completed
      setSessionsCompleted(prev => prev + 1);
      
      if (currentSessionId) {
        completeSessionMutation.mutate(currentSessionId);
      }

      const isLongBreakTime = (sessionsCompleted + 1) % settings.sessionsUntilLongBreak === 0;
      const breakDuration = isLongBreakTime ? settings.longBreakTime : settings.breakTime;
      
      setTimeLeft(breakDuration * 60);
      setIsBreak(true);
      
      toast({
        title: "Work session complete! 🎉",
        description: `Time for a ${isLongBreakTime ? 'long' : 'short'} break!`,
      });
    } else {
      // Break completed
      setTimeLeft(settings.workTime * 60);
      setIsBreak(false);
      
      toast({
        title: "Break's over! 💪",
        description: "Ready to focus again?",
      });
    }
  };

  const startTimer = () => {
    if (!isBreak && !currentSessionId) {
      // Starting a new work session
      createSessionMutation.mutate({
        duration: settings.workTime,
        category: "focus",
      });
    }
    setIsActive(true);
  };

  const pauseTimer = () => {
    setIsActive(false);
  };

  const resetTimer = () => {
    setIsActive(false);
    setIsBreak(false);
    setTimeLeft(settings.workTime * 60);
    setCurrentSessionId(null);
  };

  const setCustomTime = (minutes: number) => {
    if (!isActive) {
      setTimeLeft(minutes * 60);
      setIsBreak(false);
      setCurrentSessionId(null);
    }
  };

  return {
    timeLeft,
    isActive,
    isBreak,
    sessionsCompleted,
    settings,
    startTimer,
    pauseTimer,
    resetTimer,
    setCustomTime,
  };
}

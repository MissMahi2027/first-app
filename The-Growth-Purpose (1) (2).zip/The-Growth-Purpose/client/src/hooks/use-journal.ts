import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { JournalEntry, InsertJournalEntry } from "@shared/schema";

export function useJournal() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const journalEntriesQuery = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal"],
  });

  const createJournalEntryMutation = useMutation({
    mutationFn: async (entryData: Omit<InsertJournalEntry, "userId">) => {
      return apiRequest("POST", "/api/journal", entryData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      toast({
        title: "Journal entry saved! 📔",
        description: "Your thoughts have been recorded.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save journal entry",
        variant: "destructive",
      });
    },
  });

  const updateJournalEntryMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<InsertJournalEntry> }) => {
      return apiRequest("PATCH", `/api/journal/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      toast({
        title: "Journal entry updated! ✅",
        description: "Your entry has been successfully updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update journal entry",
        variant: "destructive",
      });
    },
  });

  return {
    entries: journalEntriesQuery.data || [],
    isLoading: journalEntriesQuery.isLoading,
    error: journalEntriesQuery.error,
    createEntry: createJournalEntryMutation.mutate,
    updateEntry: updateJournalEntryMutation.mutate,
    isCreating: createJournalEntryMutation.isPending,
    isUpdating: updateJournalEntryMutation.isPending,
  };
}

export function useTodayJournalEntry() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const today = new Date().toISOString().split('T')[0];

  const todayEntryQuery = useQuery<JournalEntry>({
    queryKey: ["/api/journal", today],
    retry: false,
  });

  const saveEntryMutation = useMutation({
    mutationFn: async (content: string) => {
      if (todayEntryQuery.data) {
        return apiRequest("PATCH", `/api/journal/${todayEntryQuery.data.id}`, {
          content,
        });
      } else {
        return apiRequest("POST", "/api/journal", {
          content,
          date: today,
          mood: "neutral",
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      toast({
        title: "Journal saved! 📔",
        description: "Your thoughts have been recorded.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save journal entry",
        variant: "destructive",
      });
    },
  });

  return {
    todayEntry: todayEntryQuery.data,
    isLoading: todayEntryQuery.isLoading,
    saveEntry: saveEntryMutation.mutate,
    isSaving: saveEntryMutation.isPending,
  };
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  category: string;
  duration: number; // in days
  difficulty: "easy" | "medium" | "hard";
  icon: string;
  color: string;
  tasks: ChallengeTask[];
  rewards: string[];
}

export interface ChallengeTask {
  id: string;
  title: string;
  description: string;
  day?: number; // which day of the challenge
  isDaily?: boolean; // if true, repeat every day
}

export const challenges: Challenge[] = [
  {
    id: "30-min-reading",
    title: "30 Minutes Reading Challenge",
    description: "Read for 30 minutes daily for one week to build a lasting reading habit.",
    category: "learning",
    duration: 7,
    difficulty: "easy",
    icon: "📖",
    color: "blue",
    tasks: [
      {
        id: "daily-read",
        title: "Read for 30 minutes",
        description: "Choose any book, article, or educational content and read for at least 30 minutes.",
        isDaily: true,
      },
      {
        id: "track-progress",
        title: "Track your reading",
        description: "Log what you read and key insights you gained.",
        isDaily: true,
      },
    ],
    rewards: ["Reading habit badge", "Knowledge seeker title", "Weekly streak bonus"],
  },
  {
    id: "phone-free-evening",
    title: "Phone-Free Evening Challenge",
    description: "Spend your evenings without using your phone for better sleep and mindfulness.",
    category: "wellness",
    duration: 14,
    difficulty: "medium",
    icon: "📱",
    color: "green",
    tasks: [
      {
        id: "phone-away",
        title: "Put phone away after 8 PM",
        description: "Place your phone in another room or in a drawer after 8 PM every evening.",
        isDaily: true,
      },
      {
        id: "evening-activity",
        title: "Choose a screen-free activity",
        description: "Read, journal, meditate, or spend time with family instead of using your phone.",
        isDaily: true,
      },
    ],
    rewards: ["Digital wellness badge", "Mindful evenings title", "Sleep quality improvement"],
  },
  {
    id: "gratitude-week",
    title: "Gratitude Week Challenge",
    description: "Practice daily gratitude to improve your mental well-being and perspective.",
    category: "mindfulness",
    duration: 7,
    difficulty: "easy",
    icon: "🙏",
    color: "purple",
    tasks: [
      {
        id: "three-gratitudes",
        title: "Write 3 things you're grateful for",
        description: "Each morning, write down three specific things you're grateful for.",
        isDaily: true,
      },
      {
        id: "express-gratitude",
        title: "Express gratitude to someone",
        description: "Thank someone in your life - family, friend, teacher, or stranger.",
        isDaily: true,
      },
    ],
    rewards: ["Gratitude warrior badge", "Positive mindset title", "Happiness boost"],
  },
  {
    id: "exercise-streak",
    title: "21-Day Exercise Streak",
    description: "Build a consistent exercise habit with 21 days of daily physical activity.",
    category: "fitness",
    duration: 21,
    difficulty: "medium",
    icon: "💪",
    color: "red",
    tasks: [
      {
        id: "daily-exercise",
        title: "Exercise for 20+ minutes",
        description: "Any physical activity counts: walking, dancing, sports, gym, yoga, or home workouts.",
        isDaily: true,
      },
      {
        id: "track-workout",
        title: "Log your workout",
        description: "Record what type of exercise you did and how you felt afterward.",
        isDaily: true,
      },
    ],
    rewards: ["Fitness champion badge", "Strong body title", "Endurance boost", "Habit master achievement"],
  },
  {
    id: "creative-week",
    title: "Creative Expression Week",
    description: "Explore your creativity through different artistic activities each day.",
    category: "creativity",
    duration: 7,
    difficulty: "easy",
    icon: "🎨",
    color: "orange",
    tasks: [
      {
        id: "day1-draw",
        title: "Draw or sketch something",
        description: "Spend at least 15 minutes drawing anything that inspires you.",
        day: 1,
      },
      {
        id: "day2-write",
        title: "Write creatively",
        description: "Write a poem, short story, or journal entry about your day.",
        day: 2,
      },
      {
        id: "day3-music",
        title: "Create or enjoy music",
        description: "Learn a song, create a playlist, or try making music with apps.",
        day: 3,
      },
      {
        id: "day4-photo",
        title: "Photography adventure",
        description: "Take creative photos of your surroundings with your phone or camera.",
        day: 4,
      },
      {
        id: "day5-craft",
        title: "Make something with your hands",
        description: "Try origami, knitting, building, or any hands-on creative project.",
        day: 5,
      },
      {
        id: "day6-perform",
        title: "Performance art",
        description: "Dance, act, or perform in front of a mirror or for family/friends.",
        day: 6,
      },
      {
        id: "day7-combine",
        title: "Combine your favorite activities",
        description: "Create something that combines your favorite creative activities from the week.",
        day: 7,
      },
    ],
    rewards: ["Creative soul badge", "Artist title", "Inspiration boost", "Creative confidence"],
  },
];

export const getChallengeById = (id: string): Challenge | undefined => {
  return challenges.find(challenge => challenge.id === id);
};

export const getChallengesByCategory = (category: string): Challenge[] => {
  return challenges.filter(challenge => challenge.category === category);
};

export const getChallengesByDifficulty = (difficulty: "easy" | "medium" | "hard"): Challenge[] => {
  return challenges.filter(challenge => challenge.difficulty === difficulty);
};

export interface Course {
  id: string;
  title: string;
  description: string;
  category: string;
  totalLessons: number;
  estimatedHours: number;
  difficulty: "beginner" | "intermediate" | "advanced";
  icon: string;
  color: string;
  lessons: CourseLesson[];
}

export interface CourseLesson {
  id: string;
  title: string;
  content: string;
  type: "text" | "video" | "interactive";
  estimatedMinutes: number;
}

export const courses: Course[] = [
  {
    id: "study-smart",
    title: "Study Smart, Not Hard",
    description: "Learn effective study techniques and time management strategies for academic success.",
    category: "productivity",
    totalLessons: 12,
    estimatedHours: 3,
    difficulty: "beginner",
    icon: "📚",
    color: "blue",
    lessons: [
      {
        id: "intro",
        title: "Introduction to Effective Studying",
        content: "Welcome to your journey of becoming a more effective student! In this lesson, we'll explore the fundamental principles that separate successful students from those who struggle despite putting in hours of work.",
        type: "text",
        estimatedMinutes: 15,
      },
      {
        id: "pomodoro",
        title: "The Pomodoro Technique",
        content: "Learn how to break your study sessions into focused 25-minute intervals with strategic breaks to maximize retention and minimize burnout.",
        type: "text",
        estimatedMinutes: 20,
      },
      {
        id: "active-recall",
        title: "Active Recall Methods",
        content: "Discover why testing yourself is far more effective than re-reading notes, and learn practical techniques to implement active recall in your studies.",
        type: "text",
        estimatedMinutes: 25,
      },
    ],
  },
  {
    id: "mindfulness-teens",
    title: "Mindfulness for Teens",
    description: "Discover meditation, stress relief, and emotional balance techniques designed for young adults.",
    category: "wellness",
    totalLessons: 8,
    estimatedHours: 2,
    difficulty: "beginner",
    icon: "🧘‍♀️",
    color: "green",
    lessons: [
      {
        id: "what-is-mindfulness",
        title: "What is Mindfulness?",
        content: "Understanding the basics of mindfulness and how it can help you manage stress, improve focus, and enhance your overall well-being as a teenager.",
        type: "text",
        estimatedMinutes: 12,
      },
      {
        id: "breathing-basics",
        title: "Breathing Basics",
        content: "Learn simple breathing techniques that you can use anywhere to calm your mind and reduce anxiety.",
        type: "interactive",
        estimatedMinutes: 15,
      },
    ],
  },
  {
    id: "teen-entrepreneur",
    title: "Teen Entrepreneur Basics",
    description: "Learn the fundamentals of starting your own business as a teenager with practical tips.",
    category: "business",
    totalLessons: 15,
    estimatedHours: 4,
    difficulty: "intermediate",
    icon: "💼",
    color: "purple",
    lessons: [
      {
        id: "entrepreneurial-mindset",
        title: "Developing an Entrepreneurial Mindset",
        content: "Explore what it means to think like an entrepreneur and how to identify opportunities around you.",
        type: "text",
        estimatedMinutes: 18,
      },
      {
        id: "business-ideas",
        title: "Finding Your Business Idea",
        content: "Learn how to brainstorm, validate, and refine business ideas that are perfect for teen entrepreneurs.",
        type: "interactive",
        estimatedMinutes: 25,
      },
    ],
  },
  {
    id: "confidence-building",
    title: "Building Self-Confidence",
    description: "Develop unshakeable confidence in yourself and your abilities.",
    category: "personal-development",
    totalLessons: 10,
    estimatedHours: 3,
    difficulty: "beginner",
    icon: "💪",
    color: "orange",
    lessons: [
      {
        id: "understanding-confidence",
        title: "Understanding True Confidence",
        content: "Learn the difference between authentic confidence and false bravado, and discover the foundations of lasting self-assurance.",
        type: "text",
        estimatedMinutes: 20,
      },
    ],
  },
  {
    id: "time-management",
    title: "Time Management Mastery",
    description: "Master the art of managing your time effectively to achieve more with less stress.",
    category: "productivity",
    totalLessons: 9,
    estimatedHours: 2.5,
    difficulty: "intermediate",
    icon: "⏰",
    color: "red",
    lessons: [
      {
        id: "time-audit",
        title: "Conducting a Time Audit",
        content: "Learn how to track and analyze where your time actually goes versus where you think it goes.",
        type: "interactive",
        estimatedMinutes: 30,
      },
    ],
  },
];

export const getCourseById = (id: string): Course | undefined => {
  return courses.find(course => course.id === id);
};

export const getCoursesByCategory = (category: string): Course[] => {
  return courses.filter(course => course.category === category);
};

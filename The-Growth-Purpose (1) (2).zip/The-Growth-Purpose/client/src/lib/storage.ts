// Local storage utilities for client-side data persistence
// This provides a fallback when the backend is not available

export interface LocalStorageData {
  habits: any[];
  journalEntries: any[];
  goals: any[];
  pomodoroSessions: any[];
  userPreferences: any;
  courseProgress: any[];
  challenges: any[];
}

const STORAGE_KEY = "growth_purpose_data";

export const getLocalData = (): LocalStorageData => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
      return JSON.parse(data);
    }
  } catch (error) {
    console.error("Error reading from localStorage:", error);
  }

  return {
    habits: [],
    journalEntries: [],
    goals: [],
    pomodoroSessions: [],
    userPreferences: {
      theme: "dark",
      notifications: true,
      pomodoroSettings: { workTime: 25, breakTime: 5 },
    },
    courseProgress: [],
    challenges: [],
  };
};

export const saveLocalData = (data: Partial<LocalStorageData>): void => {
  try {
    const existingData = getLocalData();
    const newData = { ...existingData, ...data };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
  } catch (error) {
    console.error("Error saving to localStorage:", error);
  }
};

export const clearLocalData = (): void => {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error("Error clearing localStorage:", error);
  }
};

// Utility functions for specific data types
export const saveHabits = (habits: any[]): void => {
  saveLocalData({ habits });
};

export const saveJournalEntries = (journalEntries: any[]): void => {
  saveLocalData({ journalEntries });
};

export const saveGoals = (goals: any[]): void => {
  saveLocalData({ goals });
};

export const savePomodoroSessions = (pomodoroSessions: any[]): void => {
  saveLocalData({ pomodoroSessions });
};

export const saveUserPreferences = (userPreferences: any): void => {
  saveLocalData({ userPreferences });
};

export const saveCourseProgress = (courseProgress: any[]): void => {
  saveLocalData({ courseProgress });
};

export const saveChallenges = (challenges: any[]): void => {
  saveLocalData({ challenges });
};

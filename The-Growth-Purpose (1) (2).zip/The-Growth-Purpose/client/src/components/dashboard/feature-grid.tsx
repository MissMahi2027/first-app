import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  { 
    href: "/progress", 
    icon: "📊", 
    title: "Progress Tracker",
    description: "View your growth metrics and charts"
  },
  { 
    href: "/community", 
    icon: "💬", 
    title: "Chat Rooms",
    description: "Connect with peers anonymously"
  },
  { 
    href: "/courses", 
    icon: "🎓", 
    title: "Growth Courses",
    description: "Learn new skills and mindsets"
  },
  { 
    href: "/career-guidance", 
    icon: "💼", 
    title: "Career Guide",
    description: "Explore career paths and tips"
  },
  { 
    href: "/earn-learn", 
    icon: "💰", 
    title: "Earn & Learn",
    description: "Teen-friendly income opportunities"
  },
  { 
    href: "/challenges", 
    icon: "🏆", 
    title: "Challenge Zone",
    description: "Join weekly and monthly challenges"
  },
  { 
    href: "/skincare", 
    icon: "✨", 
    title: "Skincare Guide",
    description: "Tips for healthy teen skin"
  },
  { 
    href: "/motivation-wall", 
    icon: "🎨", 
    title: "Motivation Wall",
    description: "Share and discover inspiration"
  },
  { 
    href: "/profile", 
    icon: "👤", 
    title: "Profile",
    description: "Manage your account and preferences"
  },
  { 
    href: "/calendar", 
    icon: "📅", 
    title: "Calendar",
    description: "Track events and deadlines"
  },
];

export default function FeatureGrid() {
  return (
    <div className="mt-12">
      <h2 className="text-2xl font-bold mb-6 text-center">Explore Your Growth Journey 🚀</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {features.map((feature) => (
          <Link key={feature.href} href={feature.href}>
            <Card className="card-hover cursor-pointer group border-border hover:border-secondary/50">
              <CardContent className="p-4 text-center">
                <div className="text-3xl mb-2 group-hover:animate-pulse-gentle">
                  {feature.icon}
                </div>
                <div className="text-sm font-medium mb-1">{feature.title}</div>
                <div className="text-xs text-muted-foreground">{feature.description}</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}

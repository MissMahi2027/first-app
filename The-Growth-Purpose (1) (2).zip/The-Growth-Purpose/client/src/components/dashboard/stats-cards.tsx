import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Target, Flame, BookOpen, Clock } from "lucide-react";
import type { Habit, Goal, PomodoroSession } from "@shared/schema";

export default function StatsCards() {
  const { data: habits = [] } = useQuery<Habit[]>({
    queryKey: ["/api/habits"],
  });

  const { data: goals = [] } = useQuery<Goal[]>({
    queryKey: ["/api/goals/today"],
  });

  const today = new Date().toISOString().split('T')[0];
  const { data: pomodoroSessions = [] } = useQuery<PomodoroSession[]>({
    queryKey: ["/api/pomodoro", { date: today }],
  });

  const completedGoals = goals.filter(goal => goal.isCompleted).length;
  const totalGoals = goals.length;
  
  const longestStreak = Math.max(...habits.map(h => h.longestStreak || 0), 0);
  
  const completedSessions = pomodoroSessions.filter(s => s.completed).length;
  const totalFocusTime = pomodoroSessions
    .filter(s => s.completed)
    .reduce((total, s) => total + s.duration, 0);

  const statsData = [
    {
      title: "Daily Goals",
      value: `${completedGoals}/${totalGoals}`,
      change: "+2 from yesterday",
      icon: Target,
      color: "text-green-400",
    },
    {
      title: "Habits Streak",
      value: `${longestStreak} days`,
      change: "Keep it up!",
      icon: Flame,
      color: "text-orange-400",
    },
    {
      title: "Course Progress",
      value: "68%",
      change: "2 lessons to go",
      icon: BookOpen,
      color: "text-blue-400",
    },
    {
      title: "Focus Time",
      value: `${Math.floor(totalFocusTime / 60)}h ${totalFocusTime % 60}m`,
      change: "This week",
      icon: Clock,
      color: "text-purple-400",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statsData.map((stat, index) => {
        const IconComponent = stat.icon;
        return (
          <Card key={index} className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-muted-foreground text-sm">{stat.title}</span>
                <IconComponent className={`w-5 h-5 ${stat.color}`} />
              </div>
              <div className="text-2xl font-bold text-foreground mb-1">{stat.value}</div>
              <div className={`text-sm ${stat.color}`}>{stat.change}</div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import type { Habit, HabitLog } from "@shared/schema";

export default function ProgressTracker() {
  const { data: habits = [] } = useQuery<Habit[]>({
    queryKey: ["/api/habits"],
  });

  const today = new Date().toISOString().split('T')[0];
  const { data: todayLogs = [] } = useQuery<HabitLog[]>({
    queryKey: ["/api/habit-logs/user", today],
  });

  const getHabitProgress = (habit: Habit) => {
    const log = todayLogs.find(log => log.habitId === habit.id);
    const completed = log ? log.count : 0;
    const target = habit.targetCount || 1;
    return Math.min((completed / target) * 100, 100);
  };

  const getProgressColor = (progress: number) => {
    if (progress === 100) return "bg-green-400";
    if (progress >= 75) return "bg-blue-400";
    if (progress >= 50) return "bg-yellow-400";
    return "bg-gray-400";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          📊 Today's Progress
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {habits.slice(0, 3).map((habit) => {
          const progress = getHabitProgress(habit);
          const progressColorClass = getProgressColor(progress);
          
          return (
            <div key={habit.id}>
              <div className="flex justify-between text-sm mb-2">
                <span>{habit.icon} {habit.title}</span>
                <span className="text-muted-foreground">
                  {Math.round(progress)}%
                </span>
              </div>
              <Progress 
                value={progress} 
                className="h-2"
              />
            </div>
          );
        })}
        
        {habits.length === 0 && (
          <div className="text-center text-muted-foreground py-8">
            <p>No habits yet! Start by creating your first habit.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

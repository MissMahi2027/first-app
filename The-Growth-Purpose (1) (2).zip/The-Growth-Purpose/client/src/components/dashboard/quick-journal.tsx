import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { JournalEntry } from "@shared/schema";

export default function QuickJournal() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [content, setContent] = useState("");

  const today = new Date().toISOString().split('T')[0];
  
  const { data: todayEntry } = useQuery<JournalEntry>({
    queryKey: ["/api/journal", today],
    retry: false,
  });

  const saveEntryMutation = useMutation({
    mutationFn: async (entryContent: string) => {
      if (todayEntry) {
        return apiRequest("PATCH", `/api/journal/${todayEntry.id}`, {
          content: entryContent,
        });
      } else {
        return apiRequest("POST", "/api/journal", {
          content: entryContent,
          date: today,
          mood: "neutral",
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      toast({
        title: "Journal saved! 📔",
        description: "Your thoughts have been recorded.",
      });
      setContent("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save journal entry",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    if (content.trim()) {
      saveEntryMutation.mutate(content);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            📔 Quick Journal
          </CardTitle>
          <Button variant="ghost" size="sm">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          placeholder="How are you feeling today? What went well?"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={4}
          className="resize-none"
        />
        
        <div className="flex justify-between items-center">
          <span className="text-muted-foreground text-sm">
            {todayEntry ? "Entry exists for today" : "No entry yet today"}
          </span>
          <Button
            onClick={handleSave}
            disabled={!content.trim() || saveEntryMutation.isPending}
            size="sm"
          >
            <Save className="w-4 h-4 mr-2" />
            {saveEntryMutation.isPending ? "Saving..." : "Save Entry"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Habit, HabitLog } from "@shared/schema";

export default function HabitsWidget() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: habits = [] } = useQuery<Habit[]>({
    queryKey: ["/api/habits"],
  });

  const today = new Date().toISOString().split('T')[0];
  const { data: todayLogs = [] } = useQuery<HabitLog[]>({
    queryKey: ["/api/habit-logs/user", today],
  });

  const toggleHabitMutation = useMutation({
    mutationFn: async ({ habitId, isCompleted }: { habitId: number; isCompleted: boolean }) => {
      if (isCompleted) {
        return apiRequest("POST", "/api/habit-logs", {
          habitId,
          date: today,
          count: 1,
        });
      } else {
        // In a real app, you'd need a DELETE endpoint for habit logs
        throw new Error("Cannot uncomplete habits yet");
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habit-logs/user", today] });
      toast({
        title: "Great job! 🎉",
        description: "Habit completed for today!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update habit",
        variant: "destructive",
      });
    },
  });

  const isHabitCompleted = (habitId: number) => {
    return todayLogs.some(log => log.habitId === habitId);
  };

  const handleHabitToggle = (habitId: number, checked: boolean) => {
    toggleHabitMutation.mutate({ habitId, isCompleted: checked });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            ✅ Today's Habits
          </CardTitle>
          <Link href="/habits">
            <Button size="sm" variant="outline">
              <Plus className="w-4 h-4 mr-2" />
              Add Habit
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {habits.map((habit) => {
          const isCompleted = isHabitCompleted(habit.id);
          return (
            <div key={habit.id} className="flex items-center justify-between p-3 bg-primary/10 rounded-lg">
              <div className="flex items-center space-x-3">
                <Checkbox
                  checked={isCompleted}
                  onCheckedChange={(checked) => handleHabitToggle(habit.id, checked as boolean)}
                  disabled={toggleHabitMutation.isPending}
                />
                <span className="text-sm">
                  {habit.icon} {habit.title}
                </span>
              </div>
              {habit.currentStreak && habit.currentStreak > 0 && (
                <div className="flex items-center text-xs text-muted-foreground">
                  🔥 {habit.currentStreak} day streak
                </div>
              )}
            </div>
          );
        })}

        {habits.length === 0 && (
          <div className="text-center text-muted-foreground py-4">
            <p className="text-sm">No habits yet!</p>
            <p className="text-xs">Create your first habit to get started.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

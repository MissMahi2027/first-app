import { useState } from "react";
import { Button } from "@/components/ui/button";
import { usePomodoroTimer } from "@/hooks/use-pomodoro";

export default function PomodoroTimer() {
  const {
    timeLeft,
    isActive,
    isBreak,
    startTimer,
    pauseTimer,
    resetTimer,
    setCustomTime,
  } = usePomodoroTimer();

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const presetTimes = [
    { label: "25m", minutes: 25 },
    { label: "15m", minutes: 15 },
    { label: "5m", minutes: 5 },
  ];

  return (
    <div className="bg-primary/20 rounded-lg p-4 text-center">
      <div className="text-3xl mb-2 animate-pulse-gentle">🍅</div>
      <h3 className="font-semibold mb-2">Focus Timer</h3>
      
      <div className="text-4xl font-bold text-secondary mb-4 font-mono">
        {formatTime(timeLeft)}
      </div>
      
      {isBreak && (
        <div className="text-sm text-green-400 mb-2">Break Time! 🌿</div>
      )}

      <div className="space-y-3">
        <Button
          onClick={isActive ? pauseTimer : startTimer}
          className="w-full"
          variant={isActive ? "destructive" : "default"}
        >
          {isActive ? "Pause" : "Start Focus"}
        </Button>
        
        <div className="flex space-x-2">
          {presetTimes.map((preset) => (
            <Button
              key={preset.label}
              variant="outline"
              size="sm"
              className="flex-1 text-xs"
              onClick={() => setCustomTime(preset.minutes)}
              disabled={isActive}
            >
              {preset.label}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}

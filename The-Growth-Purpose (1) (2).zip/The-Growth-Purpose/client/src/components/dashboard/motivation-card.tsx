import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import { quotes } from "@/lib/data/quotes";

export default function MotivationCard() {
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);

  const generateNewQuote = () => {
    const newIndex = (currentQuoteIndex + 1) % quotes.length;
    setCurrentQuoteIndex(newIndex);
  };

  const currentQuote = quotes[currentQuoteIndex];

  return (
    <Card className="border-2 border-secondary/20 bg-gradient-to-br from-secondary/10 to-primary/10">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            ✨ Daily Motivation
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={generateNewQuote}
            className="bg-secondary/20 hover:bg-secondary/30 border-secondary/30"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            New Quote
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <blockquote className="text-lg italic text-foreground mb-4">
          "{currentQuote.text}"
        </blockquote>
        <cite className="text-secondary text-sm font-medium">
          - {currentQuote.author}
        </cite>
      </CardContent>
    </Card>
  );
}

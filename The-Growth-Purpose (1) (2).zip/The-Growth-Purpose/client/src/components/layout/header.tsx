import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Bell, Menu, User } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { User as UserType } from "@shared/schema";

export default function Header() {
  const [location] = useLocation();
  const { data: user } = useQuery<UserType>({
    queryKey: ["/api/user"],
  });

  const navItems = [
    { href: "/", label: "Dashboard", active: location === "/" },
    { href: "/progress", label: "Progress", active: location === "/progress" },
    { href: "/courses", label: "Courses", active: location === "/courses" },
    { href: "/habits", label: "Habits", active: location === "/habits" },
    { href: "/community", label: "Community", active: location === "/community" },
    { href: "/feedback", label: "Feedback", active: location === "/feedback" },
  ];

  return (
    <header className="bg-primary/95 backdrop-blur-sm sticky top-0 z-50 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <div className="text-2xl font-bold text-white flex items-center">
                🪴 The Growth Purpose
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <span
                  className={`text-sm transition-colors ${
                    item.active
                      ? "text-white"
                      : "text-gray-300 hover:text-white"
                  }`}
                >
                  {item.label}
                </span>
              </Link>
            ))}
          </nav>

          {/* Profile & Actions */}
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-300 hover:text-white"
            >
              <Bell className="h-5 w-5" />
            </Button>
            
            <Link href="/profile">
              <Button
                variant="secondary"
                className="flex items-center space-x-2"
              >
                <User className="h-4 w-4" />
                <span className="hidden sm:inline">{user?.name || "Profile"}</span>
              </Button>
            </Link>

            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-gray-300 hover:text-white"
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}

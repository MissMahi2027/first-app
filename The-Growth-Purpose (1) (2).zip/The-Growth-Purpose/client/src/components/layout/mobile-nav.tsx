import { Link, useLocation } from "wouter";
import { Home, BarChart3, BookOpen, CheckSquare, Users, MessageCircle, Smile } from "lucide-react";

export default function MobileNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: Home, label: "Home", active: location === "/" },
    { href: "/mood-tracker", icon: Smile, label: "Mood", active: location === "/mood-tracker" },
    { href: "/habits", icon: CheckSquare, label: "Habits", active: location === "/habits" },
    { href: "/progress", icon: BarChart3, label: "Progress", active: location === "/progress" },
    { href: "/courses", icon: BookOpen, label: "Courses", active: location === "/courses" },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
      <div className="flex justify-around py-3">
        {navItems.map((item) => {
          const IconComponent = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <div className="flex flex-col items-center space-y-1">
                <IconComponent
                  className={`w-5 h-5 ${
                    item.active ? "text-secondary" : "text-muted-foreground"
                  }`}
                />
                <span
                  className={`text-xs ${
                    item.active ? "text-secondary" : "text-muted-foreground"
                  }`}
                >
                  {item.label}
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

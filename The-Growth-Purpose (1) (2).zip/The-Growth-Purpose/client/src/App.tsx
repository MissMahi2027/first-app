import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Habits from "@/pages/habits";
import Progress from "@/pages/progress";
import Courses from "@/pages/courses";
import Community from "@/pages/community";
import Profile from "@/pages/profile";
import Calendar from "@/pages/calendar";
import Journal from "@/pages/journal";
import MotivationWall from "@/pages/motivation-wall";
import CareerGuidance from "@/pages/career-guidance";
import EarnLearn from "@/pages/earn-learn";
import Feedback from "@/pages/feedback";
import Challenges from "@/pages/challenges";
import Skincare from "@/pages/skincare";
import Productivity from "@/pages/productivity";
import MoodTracker from "@/pages/mood-tracker";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/habits" component={Habits} />
      <Route path="/progress" component={Progress} />
      <Route path="/courses" component={Courses} />
      <Route path="/community" component={Community} />
      <Route path="/profile" component={Profile} />
      <Route path="/calendar" component={Calendar} />
      <Route path="/journal" component={Journal} />
      <Route path="/motivation-wall" component={MotivationWall} />
      <Route path="/career-guidance" component={CareerGuidance} />
      <Route path="/earn-learn" component={EarnLearn} />
      <Route path="/feedback" component={Feedback} />
      <Route path="/challenges" component={Challenges} />
      <Route path="/skincare" component={Skincare} />
      <Route path="/productivity" component={Productivity} />
      <Route path="/mood-tracker" component={MoodTracker} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-background text-foreground">
          <Header />
          <main className="pb-16 md:pb-0">
            <Router />
          </main>
          <MobileNav />
          <Toaster />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

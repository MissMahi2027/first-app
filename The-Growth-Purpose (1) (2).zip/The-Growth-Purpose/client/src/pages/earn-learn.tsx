import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { DollarSign, Clock, MapPin, Star, TrendingUp, Users, Briefcase, Search, Filter, ExternalLink, AlertCircle } from "lucide-react";

interface Opportunity {
  id: string;
  title: string;
  category: string;
  description: string;
  payRange: string;
  timeCommitment: string;
  ageRequirement: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  skills: string[];
  location: "remote" | "local" | "hybrid";
  earning_potential: "low" | "medium" | "high";
  tags: string[];
}

interface Resource {
  id: string;
  title: string;
  type: "course" | "article" | "tool" | "platform";
  description: string;
  category: string;
  rating: number;
  isFree: boolean;
  tags: string[];
}

const categories = [
  { id: "all", label: "All Opportunities", icon: "💼" },
  { id: "online", label: "Online Work", icon: "💻" },
  { id: "creative", label: "Creative Services", icon: "🎨" },
  { id: "local", label: "Local Jobs", icon: "🏪" },
  { id: "entrepreneurship", label: "Business Ideas", icon: "🚀" },
  { id: "skills", label: "Skill Development", icon: "📚" },
  { id: "passive", label: "Passive Income", icon: "💰" },
];

const opportunities: Opportunity[] = [
  {
    id: "freelance-writing",
    title: "Freelance Content Writing",
    category: "online",
    description: "Write blog posts, articles, and web content for businesses. Great for teens who love writing and want to build a portfolio.",
    payRange: "$15-50 per article",
    timeCommitment: "5-20 hours/week",
    ageRequirement: "16+",
    difficulty: "beginner",
    skills: ["Writing", "Research", "Grammar", "SEO basics"],
    location: "remote",
    earning_potential: "medium",
    tags: ["writing", "flexible", "portfolio-building"],
  },
  {
    id: "social-media-management",
    title: "Social Media Manager",
    category: "online",
    description: "Manage social media accounts for small businesses. Perfect for teens who understand current social media trends.",
    payRange: "$300-800/month per client",
    timeCommitment: "10-15 hours/week",
    ageRequirement: "16+",
    difficulty: "beginner",
    skills: ["Social Media", "Content Creation", "Analytics", "Communication"],
    location: "remote",
    earning_potential: "medium",
    tags: ["social-media", "marketing", "creative"],
  },
  {
    id: "tutoring",
    title: "Online Tutoring",
    category: "online",
    description: "Tutor younger students in subjects you excel at. Share your knowledge while earning money.",
    payRange: "$15-25/hour",
    timeCommitment: "5-15 hours/week",
    ageRequirement: "14+",
    difficulty: "beginner",
    skills: ["Subject expertise", "Communication", "Patience", "Teaching"],
    location: "remote",
    earning_potential: "medium",
    tags: ["education", "helping-others", "flexible"],
  },
  {
    id: "graphic-design",
    title: "Freelance Graphic Design",
    category: "creative",
    description: "Create logos, social media graphics, and marketing materials for businesses and individuals.",
    payRange: "$25-100 per project",
    timeCommitment: "10-20 hours/week",
    ageRequirement: "16+",
    difficulty: "intermediate",
    skills: ["Adobe Creative Suite", "Design principles", "Creativity", "Client communication"],
    location: "remote",
    earning_potential: "high",
    tags: ["design", "creative", "portfolio"],
  },
  {
    id: "pet-sitting",
    title: "Pet Sitting & Dog Walking",
    category: "local",
    description: "Take care of pets in your neighborhood. Great for animal lovers who want to earn money locally.",
    payRange: "$15-30/day",
    timeCommitment: "1-4 hours/day",
    ageRequirement: "13+",
    difficulty: "beginner",
    skills: ["Animal care", "Responsibility", "Communication", "Time management"],
    location: "local",
    earning_potential: "low",
    tags: ["animals", "local", "flexible"],
  },
  {
    id: "lawn-care",
    title: "Lawn Care & Landscaping",
    category: "local",
    description: "Provide lawn mowing, weeding, and basic landscaping services in your neighborhood.",
    payRange: "$25-50 per job",
    timeCommitment: "10-20 hours/week",
    ageRequirement: "14+",
    difficulty: "beginner",
    skills: ["Physical fitness", "Attention to detail", "Equipment handling", "Customer service"],
    location: "local",
    earning_potential: "medium",
    tags: ["outdoor", "physical", "seasonal"],
  },
  {
    id: "dropshipping",
    title: "Dropshipping Business",
    category: "entrepreneurship",
    description: "Start an online store without inventory. Learn e-commerce while building your own business.",
    payRange: "$100-1000+/month",
    timeCommitment: "15-30 hours/week",
    ageRequirement: "16+",
    difficulty: "advanced",
    skills: ["E-commerce", "Marketing", "Customer service", "Business management"],
    location: "remote",
    earning_potential: "high",
    tags: ["business", "e-commerce", "scalable"],
  },
  {
    id: "youtube-creator",
    title: "YouTube Content Creator",
    category: "creative",
    description: "Create educational, entertaining, or niche content on YouTube. Build an audience and monetize through ads and sponsorships.",
    payRange: "$0-500+/month (variable)",
    timeCommitment: "10-25 hours/week",
    ageRequirement: "13+ (with parental consent)",
    difficulty: "intermediate",
    skills: ["Video editing", "Content creation", "Marketing", "Consistency"],
    location: "remote",
    earning_potential: "high",
    tags: ["content-creation", "long-term", "creative"],
  },
];

const resources: Resource[] = [
  {
    id: "fiverr-guide",
    title: "Complete Guide to Starting on Fiverr",
    type: "article",
    description: "Learn how to create compelling gigs, price your services, and build a successful freelance business on Fiverr.",
    category: "freelancing",
    rating: 4.8,
    isFree: true,
    tags: ["freelancing", "guide", "beginner"],
  },
  {
    id: "canva-course",
    title: "Graphic Design Basics with Canva",
    type: "course",
    description: "Master Canva to create professional designs for clients. No prior experience needed.",
    category: "design",
    rating: 4.6,
    isFree: true,
    tags: ["design", "canva", "beginner"],
  },
  {
    id: "etsy-shop",
    title: "How to Start an Etsy Shop",
    type: "course",
    description: "Complete guide to setting up and running a successful Etsy shop for handmade or digital products.",
    category: "e-commerce",
    rating: 4.7,
    isFree: false,
    tags: ["etsy", "business", "crafts"],
  },
  {
    id: "content-calendar",
    title: "Social Media Content Calendar Template",
    type: "tool",
    description: "Free template to plan and organize social media content for your clients or personal brand.",
    category: "social-media",
    rating: 4.5,
    isFree: true,
    tags: ["social-media", "template", "organization"],
  },
  {
    id: "upwork-platform",
    title: "Upwork Freelancing Platform",
    type: "platform",
    description: "One of the largest freelancing platforms. Find projects in writing, design, programming, and more.",
    category: "freelancing",
    rating: 4.2,
    isFree: true,
    tags: ["freelancing", "platform", "diverse"],
  },
];

export default function EarnLearn() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [difficultyFilter, setDifficultyFilter] = useState("all");

  const filteredOpportunities = opportunities.filter(opp => {
    const matchesCategory = selectedCategory === "all" || opp.category === selectedCategory;
    const matchesSearch = opp.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         opp.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         opp.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesDifficulty = difficultyFilter === "all" || opp.difficulty === difficultyFilter;
    return matchesCategory && matchesSearch && matchesDifficulty;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "text-green-400 border-green-400";
      case "intermediate": return "text-yellow-400 border-yellow-400";
      case "advanced": return "text-red-400 border-red-400";
      default: return "text-gray-400 border-gray-400";
    }
  };

  const getEarningColor = (earning: string) => {
    switch (earning) {
      case "low": return "text-yellow-400";
      case "medium": return "text-orange-400";
      case "high": return "text-green-400";
      default: return "text-gray-400";
    }
  };

  if (selectedOpportunity) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Button 
            variant="ghost" 
            onClick={() => setSelectedOpportunity(null)}
            className="mb-6"
          >
            ← Back to Opportunities
          </Button>

          <div className="space-y-6">
            {/* Opportunity Header */}
            <Card>
              <CardContent className="p-8">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h1 className="text-3xl font-bold mb-2">{selectedOpportunity.title}</h1>
                    <Badge variant="outline" className="mb-4">
                      {categories.find(c => c.id === selectedOpportunity.category)?.icon} {" "}
                      {categories.find(c => c.id === selectedOpportunity.category)?.label}
                    </Badge>
                    <p className="text-muted-foreground">{selectedOpportunity.description}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="p-4 bg-green-400/10 rounded-lg">
                    <DollarSign className="w-6 h-6 text-green-400 mb-2" />
                    <p className="text-sm text-muted-foreground">Pay Range</p>
                    <p className="font-semibold">{selectedOpportunity.payRange}</p>
                  </div>
                  
                  <div className="p-4 bg-blue-400/10 rounded-lg">
                    <Clock className="w-6 h-6 text-blue-400 mb-2" />
                    <p className="text-sm text-muted-foreground">Time Commitment</p>
                    <p className="font-semibold">{selectedOpportunity.timeCommitment}</p>
                  </div>
                  
                  <div className="p-4 bg-purple-400/10 rounded-lg">
                    <Users className="w-6 h-6 text-purple-400 mb-2" />
                    <p className="text-sm text-muted-foreground">Age Requirement</p>
                    <p className="font-semibold">{selectedOpportunity.ageRequirement}</p>
                  </div>
                  
                  <div className="p-4 bg-orange-400/10 rounded-lg">
                    <MapPin className="w-6 h-6 text-orange-400 mb-2" />
                    <p className="text-sm text-muted-foreground">Location</p>
                    <p className="font-semibold capitalize">{selectedOpportunity.location}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Skills and Details */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Skills Needed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {selectedOpportunity.skills.map((skill) => (
                      <Badge key={skill} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Opportunity Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Difficulty:</span>
                    <Badge variant="outline" className={getDifficultyColor(selectedOpportunity.difficulty)}>
                      {selectedOpportunity.difficulty}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Earning Potential:</span>
                    <span className={`font-medium ${getEarningColor(selectedOpportunity.earning_potential)}`}>
                      {selectedOpportunity.earning_potential}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Work Type:</span>
                    <span className="font-medium capitalize">{selectedOpportunity.location}</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Getting Started Guide */}
            <Card>
              <CardHeader>
                <CardTitle>How to Get Started</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-secondary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-medium">1</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Develop Your Skills</h4>
                      <p className="text-sm text-muted-foreground">
                        Focus on building: {selectedOpportunity.skills.slice(0, 3).join(", ")}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-secondary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-medium">2</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Create a Portfolio</h4>
                      <p className="text-sm text-muted-foreground">
                        Build examples of your work to show potential clients or employers
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-secondary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-medium">3</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Start Small</h4>
                      <p className="text-sm text-muted-foreground">
                        Begin with smaller projects to build experience and confidence
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-secondary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-medium">4</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Network and Market Yourself</h4>
                      <p className="text-sm text-muted-foreground">
                        Use social media, online platforms, and word-of-mouth to find opportunities
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Safety Notice */}
            <Card className="border-yellow-400/30 bg-yellow-400/5">
              <CardContent className="p-6">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="w-6 h-6 text-yellow-400 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-yellow-400 mb-2">Safety First</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Always get parental permission before starting any work</li>
                      <li>• Never share personal information with strangers</li>
                      <li>• Use secure payment methods and platforms</li>
                      <li>• Be cautious of opportunities that seem too good to be true</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Earn & Learn 💰</h1>
          <p className="text-muted-foreground mt-2">
            Discover teen-friendly ways to earn money while building valuable skills for your future.
          </p>
        </div>

        {/* Safety Notice */}
        <Card className="mb-8 border-blue-400/30 bg-blue-400/5">
          <CardContent className="p-6">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-6 h-6 text-blue-400 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-blue-400 mb-2">Important Safety Guidelines</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Always involve your parents/guardians in financial decisions</li>
                  <li>• Verify the legitimacy of opportunities and platforms</li>
                  <li>• Never pay upfront fees for "guaranteed" work</li>
                  <li>• Keep records of your earnings for tax purposes</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-green-400/20 rounded-lg">
                  <DollarSign className="w-6 h-6 text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Opportunities</p>
                  <p className="text-2xl font-bold">{opportunities.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-400/20 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">High Earning</p>
                  <p className="text-2xl font-bold">{opportunities.filter(o => o.earning_potential === "high").length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-purple-400/20 rounded-lg">
                  <Briefcase className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Remote Work</p>
                  <p className="text-2xl font-bold">{opportunities.filter(o => o.location === "remote").length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-orange-400/20 rounded-lg">
                  <Star className="w-6 h-6 text-orange-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Beginner Friendly</p>
                  <p className="text-2xl font-bold">{opportunities.filter(o => o.difficulty === "beginner").length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="opportunities" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="opportunities">Earning Opportunities</TabsTrigger>
            <TabsTrigger value="resources">Learning Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="opportunities" className="space-y-6">
            {/* Search and Filter */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      placeholder="Search opportunities, skills, or categories..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="flex items-center space-x-2 overflow-x-auto">
                    <Filter className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    {categories.map((category) => (
                      <Button
                        key={category.id}
                        variant={selectedCategory === category.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedCategory(category.id)}
                        className="flex-shrink-0"
                      >
                        <span className="mr-2">{category.icon}</span>
                        {category.label}
                      </Button>
                    ))}
                  </div>
                  <select 
                    value={difficultyFilter} 
                    onChange={(e) => setDifficultyFilter(e.target.value)}
                    className="px-3 py-2 border border-border rounded-lg bg-background text-sm"
                  >
                    <option value="all">All Levels</option>
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </div>
              </CardContent>
            </Card>

            {/* Opportunities Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredOpportunities.map((opportunity) => (
                <Card key={opportunity.id} className="card-hover cursor-pointer" onClick={() => setSelectedOpportunity(opportunity)}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold mb-2">{opportunity.title}</h3>
                        <div className="flex items-center space-x-2 mb-3">
                          <Badge variant="outline" className={getDifficultyColor(opportunity.difficulty)}>
                            {opportunity.difficulty}
                          </Badge>
                          <Badge variant="outline">
                            {categories.find(c => c.id === opportunity.category)?.icon} {" "}
                            {categories.find(c => c.id === opportunity.category)?.label}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                      {opportunity.description}
                    </p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-sm">
                        <DollarSign className="w-4 h-4 mr-2 text-green-400" />
                        <span>{opportunity.payRange}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <Clock className="w-4 h-4 mr-2 text-blue-400" />
                        <span>{opportunity.timeCommitment}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <MapPin className="w-4 h-4 mr-2 text-orange-400" />
                        <span className="capitalize">{opportunity.location}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {opportunity.skills.slice(0, 3).map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                      {opportunity.skills.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{opportunity.skills.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredOpportunities.length === 0 && (
              <Card>
                <CardContent className="p-8 text-center">
                  <div className="text-6xl mb-4">🔍</div>
                  <h3 className="text-lg font-semibold mb-2">No opportunities found</h3>
                  <p className="text-muted-foreground">
                    Try adjusting your search or filter criteria
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="resources" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {resources.map((resource) => (
                <Card key={resource.id} className="card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="capitalize">
                          {resource.type}
                        </Badge>
                        {resource.isFree ? (
                          <Badge className="bg-green-400 text-white">Free</Badge>
                        ) : (
                          <Badge variant="outline">Paid</Badge>
                        )}
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-sm">{resource.rating}</span>
                      </div>
                    </div>
                    
                    <h3 className="text-lg font-semibold mb-3">{resource.title}</h3>
                    <p className="text-muted-foreground text-sm mb-4">
                      {resource.description}
                    </p>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {resource.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <Button variant="outline" className="w-full">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Access Resource
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

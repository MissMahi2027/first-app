import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Plus, Heart, MessageCircle, Share2, Flag, TrendingUp, Clock, Star } from "lucide-react";

interface MotivationPost {
  id: string;
  author: string;
  avatar: string;
  content: string;
  image?: string;
  category: string;
  likes: number;
  comments: number;
  isLiked: boolean;
  timestamp: string;
  tags: string[];
}

interface Comment {
  id: string;
  author: string;
  avatar: string;
  content: string;
  timestamp: string;
  likes: number;
}

const categories = [
  { id: "all", label: "All", icon: "🌟" },
  { id: "quotes", label: "Quotes", icon: "💭" },
  { id: "achievements", label: "Achievements", icon: "🏆" },
  { id: "art", label: "Art & Creativity", icon: "🎨" },
  { id: "goals", label: "Goals", icon: "🎯" },
  { id: "inspiration", label: "Daily Inspiration", icon: "✨" },
  { id: "stories", label: "Success Stories", icon: "📖" },
];

const samplePosts: MotivationPost[] = [
  {
    id: "1",
    author: "DreamChaser",
    avatar: "D",
    content: "Just finished my first 5K run! 🏃‍♀️ Six months ago I couldn't even run for 2 minutes. Remember: every expert was once a beginner. Your pace doesn't matter as long as you don't stop! 💪",
    category: "achievements",
    likes: 47,
    comments: 12,
    isLiked: false,
    timestamp: "2 hours ago",
    tags: ["fitness", "perseverance", "goals"],
  },
  {
    id: "2",
    author: "ArtisticSoul",
    avatar: "A",
    content: "\"The way to get started is to quit talking and begin doing.\" - Walt Disney\n\nThis quote helped me overcome my fear of sharing my art. Today I posted my first drawing online. Scared but excited! 🎨✨",
    category: "quotes",
    likes: 63,
    comments: 18,
    isLiked: true,
    timestamp: "5 hours ago",
    tags: ["art", "courage", "quotes"],
  },
  {
    id: "3",
    author: "StudyWarrior",
    avatar: "S",
    content: "Update: Got accepted into my dream college! 🎓 To everyone struggling with applications - don't give up. I was rejected 3 times before this acceptance. Every 'no' was redirecting me to my 'yes'! Keep pushing! 📚💙",
    category: "achievements",
    likes: 89,
    comments: 25,
    isLiked: false,
    timestamp: "8 hours ago",
    tags: ["education", "persistence", "success"],
  },
  {
    id: "4",
    author: "MindfulTeen",
    avatar: "M",
    content: "Daily reminder: You don't have to be perfect. You just have to be yourself. 🌱 Progress, not perfection. Be kind to yourself today and every day. You're doing better than you think! 💚",
    category: "inspiration",
    likes: 112,
    comments: 31,
    isLiked: true,
    timestamp: "12 hours ago",
    tags: ["selfcare", "mindfulness", "growth"],
  },
  {
    id: "5",
    author: "TechInnovator",
    avatar: "T",
    content: "Built my first mobile app! 📱 Started learning to code 8 months ago with zero experience. Thanks to all the free resources online and the amazing coding community. If you're thinking about learning to code - just start! The journey is worth it 💻✨",
    category: "achievements",
    likes: 76,
    comments: 19,
    isLiked: false,
    timestamp: "1 day ago",
    tags: ["coding", "learning", "technology"],
  },
];

export default function MotivationWall() {
  const [posts, setPosts] = useState<MotivationPost[]>(samplePosts);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newPost, setNewPost] = useState({ content: "", category: "inspiration", tags: "" });
  const [selectedPost, setSelectedPost] = useState<MotivationPost | null>(null);

  const filteredPosts = selectedCategory === "all" 
    ? posts 
    : posts.filter(post => post.category === selectedCategory);

  const handleLike = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { 
            ...post, 
            likes: post.isLiked ? post.likes - 1 : post.likes + 1,
            isLiked: !post.isLiked 
          }
        : post
    ));
  };

  const handleSubmitPost = () => {
    if (newPost.content.trim()) {
      const post: MotivationPost = {
        id: Date.now().toString(),
        author: "You",
        avatar: "Y",
        content: newPost.content,
        category: newPost.category,
        likes: 0,
        comments: 0,
        isLiked: false,
        timestamp: "now",
        tags: newPost.tags.split(",").map(tag => tag.trim()).filter(Boolean),
      };
      setPosts([post, ...posts]);
      setNewPost({ content: "", category: "inspiration", tags: "" });
      setIsDialogOpen(false);
    }
  };

  const getCategoryIcon = (category: string) => {
    const cat = categories.find(c => c.id === category);
    return cat?.icon || "🌟";
  };

  const getCategoryLabel = (category: string) => {
    const cat = categories.find(c => c.id === category);
    return cat?.label || "General";
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Motivation Wall 🎨</h1>
            <p className="text-muted-foreground mt-2">
              Share your inspiring moments and discover motivation from fellow teens.
            </p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Share Inspiration
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Share Your Inspiration</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Category</label>
                  <select 
                    value={newPost.category} 
                    onChange={(e) => setNewPost({...newPost, category: e.target.value})}
                    className="w-full mt-1 p-2 border border-border rounded-lg bg-background"
                  >
                    {categories.slice(1).map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.icon} {cat.label}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="text-sm font-medium">Your Message</label>
                  <Textarea
                    placeholder="Share something inspiring, motivational, or encouraging..."
                    value={newPost.content}
                    onChange={(e) => setNewPost({...newPost, content: e.target.value})}
                    rows={6}
                    className="mt-1 resize-none"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">Tags (optional)</label>
                  <Input
                    placeholder="motivation, goals, success (comma separated)"
                    value={newPost.tags}
                    onChange={(e) => setNewPost({...newPost, tags: e.target.value})}
                    className="mt-1"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Add tags to help others find your post
                  </p>
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => setIsDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    className="flex-1"
                    onClick={handleSubmitPost}
                    disabled={!newPost.content.trim()}
                  >
                    Share
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Community Guidelines */}
        <Card className="mb-8 border-blue-400/30 bg-blue-400/5">
          <CardContent className="p-6">
            <div className="flex items-start space-x-3">
              <div className="text-2xl">💙</div>
              <div>
                <h3 className="font-semibold text-blue-400 mb-2">Community Guidelines</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Share positive, encouraging, and inspiring content</li>
                  <li>• Respect others' experiences and perspectives</li>
                  <li>• No personal information or contact details</li>
                  <li>• Report inappropriate content using the flag button</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="feed" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="feed">Inspiration Feed</TabsTrigger>
                <TabsTrigger value="trending">Trending</TabsTrigger>
                <TabsTrigger value="recent">Most Recent</TabsTrigger>
              </TabsList>

              <TabsContent value="feed" className="space-y-6">
                {/* Category Filter */}
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-2 overflow-x-auto">
                      <span className="text-sm font-medium flex-shrink-0">Filter:</span>
                      {categories.map((category) => (
                        <Button
                          key={category.id}
                          variant={selectedCategory === category.id ? "default" : "outline"}
                          size="sm"
                          onClick={() => setSelectedCategory(category.id)}
                          className="flex-shrink-0"
                        >
                          <span className="mr-2">{category.icon}</span>
                          {category.label}
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Posts */}
                <div className="space-y-6">
                  {filteredPosts.map((post) => (
                    <Card key={post.id} className="card-hover">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <Avatar className="w-10 h-10">
                            <AvatarFallback className="bg-secondary text-secondary-foreground">
                              {post.avatar}
                            </AvatarFallback>
                          </Avatar>
                          
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <span className="font-medium">{post.author}</span>
                              <Badge variant="outline" className="text-xs">
                                {getCategoryIcon(post.category)} {getCategoryLabel(post.category)}
                              </Badge>
                              <span className="text-sm text-muted-foreground">{post.timestamp}</span>
                            </div>
                            
                            <div className="prose prose-sm max-w-none text-foreground mb-4">
                              <p className="whitespace-pre-wrap">{post.content}</p>
                            </div>

                            {post.tags.length > 0 && (
                              <div className="flex flex-wrap gap-2 mb-4">
                                {post.tags.map((tag) => (
                                  <Badge key={tag} variant="secondary" className="text-xs">
                                    #{tag}
                                  </Badge>
                                ))}
                              </div>
                            )}

                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-4">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleLike(post.id)}
                                  className={`${post.isLiked ? 'text-red-400' : 'text-muted-foreground'}`}
                                >
                                  <Heart className={`w-4 h-4 mr-1 ${post.isLiked ? 'fill-current' : ''}`} />
                                  {post.likes}
                                </Button>
                                <Button variant="ghost" size="sm" className="text-muted-foreground">
                                  <MessageCircle className="w-4 h-4 mr-1" />
                                  {post.comments}
                                </Button>
                                <Button variant="ghost" size="sm" className="text-muted-foreground">
                                  <Share2 className="w-4 h-4 mr-1" />
                                  Share
                                </Button>
                              </div>
                              <Button variant="ghost" size="sm" className="text-muted-foreground">
                                <Flag className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="trending" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <TrendingUp className="w-5 h-5 mr-2" />
                      Trending Posts This Week
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {filteredPosts
                        .sort((a, b) => b.likes - a.likes)
                        .slice(0, 5)
                        .map((post, index) => (
                          <div key={post.id} className="flex items-start space-x-3 p-3 border border-border rounded-lg">
                            <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center flex-shrink-0">
                              <span className="text-sm font-medium">#{index + 1}</span>
                            </div>
                            <div className="flex-1">
                              <p className="text-sm line-clamp-2">{post.content}</p>
                              <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                                <span>by {post.author}</span>
                                <span>{post.likes} likes</span>
                                <span>{post.comments} comments</span>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="recent" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Clock className="w-5 h-5 mr-2" />
                      Latest Posts
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {filteredPosts.map((post) => (
                        <div key={post.id} className="flex items-start space-x-3 p-3 border border-border rounded-lg">
                          <Avatar className="w-8 h-8">
                            <AvatarFallback className="bg-secondary text-secondary-foreground text-sm">
                              {post.avatar}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <span className="font-medium text-sm">{post.author}</span>
                              <span className="text-xs text-muted-foreground">{post.timestamp}</span>
                            </div>
                            <p className="text-sm line-clamp-2">{post.content}</p>
                            <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                              <span>{post.likes} likes</span>
                              <span>{post.comments} comments</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Community Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  📊 Community Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center p-3 bg-purple-400/10 rounded-lg">
                    <div className="text-xl font-bold text-purple-400 mb-1">1,247</div>
                    <div className="text-xs text-muted-foreground">Total Posts</div>
                  </div>
                  <div className="text-center p-3 bg-blue-400/10 rounded-lg">
                    <div className="text-xl font-bold text-blue-400 mb-1">543</div>
                    <div className="text-xs text-muted-foreground">Active Members</div>
                  </div>
                  <div className="text-center p-3 bg-green-400/10 rounded-lg">
                    <div className="text-xl font-bold text-green-400 mb-1">89</div>
                    <div className="text-xs text-muted-foreground">Posts Today</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Top Contributors */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="w-5 h-5 mr-2" />
                  Top Contributors
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {["MindfulTeen", "DreamChaser", "ArtisticSoul", "StudyWarrior", "TechInnovator"].map((user, index) => (
                    <div key={user} className="flex items-center space-x-3">
                      <div className="w-6 h-6 bg-secondary/20 rounded-full flex items-center justify-center">
                        <span className="text-xs font-medium">{index + 1}</span>
                      </div>
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-secondary text-secondary-foreground text-sm">
                          {user.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm font-medium">{user}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Popular Tags */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  🏷️ Trending Tags
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {["motivation", "goals", "success", "growth", "mindfulness", "art", "coding", "fitness", "study", "creativity"].map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs cursor-pointer hover:bg-secondary/20">
                      #{tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Daily Challenge */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  🌟 Daily Challenge
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-4xl mb-3">💭</div>
                  <p className="text-sm font-medium mb-2">Share a Quote That Inspires You</p>
                  <p className="text-xs text-muted-foreground mb-4">
                    Post your favorite motivational quote and tell us why it speaks to you.
                  </p>
                  <Button size="sm" className="w-full">
                    Participate
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useProfile } from "@/hooks/use-profile";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { User, Settings, Bell, Shield, Edit2, Save } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import type { InsertUser, InsertUserPreferences } from "@shared/schema";

const profileSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address"),
  age: z.number().min(13, "Must be at least 13").max(25, "Must be under 25").optional(),
  interests: z.array(z.string()).optional(),
  goals: z.array(z.string()).optional(),
});

const preferencesSchema = z.object({
  theme: z.string(),
  notifications: z.boolean(),
  weeklyGoal: z.number().min(1).max(50),
  skinType: z.string().optional(),
});

type ProfileFormData = z.infer<typeof profileSchema>;
type PreferencesFormData = z.infer<typeof preferencesSchema>;

const interestOptions = [
  "Technology", "Reading", "Fitness", "Music", "Art", "Science",
  "Sports", "Gaming", "Photography", "Cooking", "Travel", "Fashion",
  "Environment", "Business", "Writing", "Languages"
];

const goalOptions = [
  "Improve study habits", "Build confidence", "Learn new skills",
  "Get better grades", "Make new friends", "Stay healthy",
  "Save money", "Learn programming", "Start a business",
  "Read more books", "Exercise regularly", "Reduce stress"
];

export default function Profile() {
  const { user, preferences, updateUser, updatePreferences, isUpdatingUser, isUpdatingPreferences } = useProfile();
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [selectedInterests, setSelectedInterests] = useState<string[]>(user?.interests || []);
  const [selectedGoals, setSelectedGoals] = useState<string[]>(user?.goals || []);

  const profileForm = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      age: user?.age || undefined,
      interests: user?.interests || [],
      goals: user?.goals || [],
    },
  });

  const preferencesForm = useForm<PreferencesFormData>({
    resolver: zodResolver(preferencesSchema),
    defaultValues: {
      theme: preferences?.theme || "dark",
      notifications: preferences?.notifications ?? true,
      weeklyGoal: preferences?.weeklyGoal || 5,
      skinType: preferences?.skinType || "",
    },
  });

  const onProfileSubmit = (data: ProfileFormData) => {
    updateUser({ 
      ...data, 
      interests: selectedInterests,
      goals: selectedGoals 
    });
    setIsEditingProfile(false);
  };

  const onPreferencesSubmit = (data: PreferencesFormData) => {
    updatePreferences(data);
  };

  const toggleInterest = (interest: string) => {
    setSelectedInterests(prev => 
      prev.includes(interest) 
        ? prev.filter(i => i !== interest)
        : [...prev, interest]
    );
  };

  const toggleGoal = (goal: string) => {
    setSelectedGoals(prev => 
      prev.includes(goal) 
        ? prev.filter(g => g !== goal)
        : [...prev, goal]
    );
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">👤</div>
          <h2 className="text-xl font-semibold mb-2">Loading profile...</h2>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Profile 👤</h1>
          <p className="text-muted-foreground mt-2">
            Manage your account settings and preferences.
          </p>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
            <TabsTrigger value="privacy">Privacy & Safety</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            {/* Profile Overview */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <User className="w-5 h-5 mr-2" />
                    Profile Information
                  </CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsEditingProfile(!isEditingProfile)}
                  >
                    <Edit2 className="w-4 h-4 mr-2" />
                    {isEditingProfile ? "Cancel" : "Edit"}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isEditingProfile ? (
                  <Form {...profileForm}>
                    <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-6">
                      <div className="flex items-center space-x-6">
                        <Avatar className="w-20 h-20">
                          <AvatarFallback className="bg-secondary text-secondary-foreground text-2xl">
                            {user.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <FormField
                            control={profileForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Name</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={profileForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input type="email" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={profileForm.control}
                          name="age"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Age (Optional)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  min="13"
                                  max="25"
                                  {...field}
                                  onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      {/* Interests */}
                      <div>
                        <Label className="text-sm font-medium">Interests</Label>
                        <p className="text-sm text-muted-foreground mb-3">
                          Select topics that interest you (helps personalize your experience)
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {interestOptions.map((interest) => (
                            <Badge
                              key={interest}
                              variant={selectedInterests.includes(interest) ? "default" : "outline"}
                              className="cursor-pointer"
                              onClick={() => toggleInterest(interest)}
                            >
                              {interest}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Goals */}
                      <div>
                        <Label className="text-sm font-medium">Personal Goals</Label>
                        <p className="text-sm text-muted-foreground mb-3">
                          What would you like to work on?
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {goalOptions.map((goal) => (
                            <Badge
                              key={goal}
                              variant={selectedGoals.includes(goal) ? "default" : "outline"}
                              className="cursor-pointer"
                              onClick={() => toggleGoal(goal)}
                            >
                              {goal}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button type="submit" disabled={isUpdatingUser}>
                          <Save className="w-4 h-4 mr-2" />
                          {isUpdatingUser ? "Saving..." : "Save Changes"}
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsEditingProfile(false)}
                        >
                          Cancel
                        </Button>
                      </div>
                    </form>
                  </Form>
                ) : (
                  <div className="space-y-6">
                    <div className="flex items-center space-x-6">
                      <Avatar className="w-20 h-20">
                        <AvatarFallback className="bg-secondary text-secondary-foreground text-2xl">
                          {user.name.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h2 className="text-2xl font-bold">{user.name}</h2>
                        <p className="text-muted-foreground">{user.email}</p>
                        {user.age && (
                          <p className="text-sm text-muted-foreground">Age: {user.age}</p>
                        )}
                      </div>
                    </div>

                    {user.interests && user.interests.length > 0 && (
                      <div>
                        <h3 className="font-medium mb-2">Interests</h3>
                        <div className="flex flex-wrap gap-2">
                          {user.interests.map((interest) => (
                            <Badge key={interest} variant="secondary">
                              {interest}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {user.goals && user.goals.length > 0 && (
                      <div>
                        <h3 className="font-medium mb-2">Goals</h3>
                        <div className="flex flex-wrap gap-2">
                          {user.goals.map((goal) => (
                            <Badge key={goal} variant="outline">
                              {goal}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preferences" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Settings className="w-5 h-5 mr-2" />
                  App Preferences
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...preferencesForm}>
                  <form onSubmit={preferencesForm.handleSubmit(onPreferencesSubmit)} className="space-y-6">
                    <FormField
                      control={preferencesForm.control}
                      name="theme"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Theme</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select theme" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="dark">Dark</SelectItem>
                              <SelectItem value="light">Light</SelectItem>
                              <SelectItem value="system">System</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={preferencesForm.control}
                      name="notifications"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Push Notifications</FormLabel>
                            <div className="text-sm text-muted-foreground">
                              Receive notifications for habit reminders and achievements
                            </div>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={preferencesForm.control}
                      name="weeklyGoal"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Weekly Focus Goal (hours)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="1"
                              max="50"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <div className="text-sm text-muted-foreground">
                            Set your weekly goal for focused study/work time
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={preferencesForm.control}
                      name="skinType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Skin Type (Optional)</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select your skin type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="normal">Normal</SelectItem>
                              <SelectItem value="oily">Oily</SelectItem>
                              <SelectItem value="dry">Dry</SelectItem>
                              <SelectItem value="combination">Combination</SelectItem>
                              <SelectItem value="sensitive">Sensitive</SelectItem>
                            </SelectContent>
                          </Select>
                          <div className="text-sm text-muted-foreground">
                            Help us provide personalized skincare tips
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" disabled={isUpdatingPreferences}>
                      <Save className="w-4 h-4 mr-2" />
                      {isUpdatingPreferences ? "Saving..." : "Save Preferences"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="privacy" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="w-5 h-5 mr-2" />
                  Privacy & Safety
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div>
                      <h3 className="font-medium">Anonymous Chat</h3>
                      <p className="text-sm text-muted-foreground">
                        Your identity is protected in community chats
                      </p>
                    </div>
                    <Badge variant="outline" className="text-green-400 border-green-400">
                      Enabled
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div>
                      <h3 className="font-medium">Data Privacy</h3>
                      <p className="text-sm text-muted-foreground">
                        Your personal data is encrypted and secure
                      </p>
                    </div>
                    <Badge variant="outline" className="text-green-400 border-green-400">
                      Protected
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div>
                      <h3 className="font-medium">Content Moderation</h3>
                      <p className="text-sm text-muted-foreground">
                        All community content is moderated for safety
                      </p>
                    </div>
                    <Badge variant="outline" className="text-green-400 border-green-400">
                      Active
                    </Badge>
                  </div>
                </div>

                <div className="border-t border-border pt-6">
                  <h3 className="font-medium mb-4">Safety Resources</h3>
                  <div className="space-y-2 text-sm">
                    <p>• Report inappropriate behavior using the flag button</p>
                    <p>• Block users who make you uncomfortable</p>
                    <p>• Never share personal information in public chats</p>
                    <p>• Contact support if you need help: support@growthpurpose.com</p>
                  </div>
                </div>

                <div className="border-t border-border pt-6">
                  <h3 className="font-medium mb-4 text-red-400">Account Actions</h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start">
                      Download My Data
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-red-400 border-red-400 hover:bg-red-400/10">
                      Delete Account
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

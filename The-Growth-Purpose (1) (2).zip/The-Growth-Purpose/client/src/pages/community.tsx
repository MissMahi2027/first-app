import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Users, MessageCircle, Send, Heart, Flag, Shield } from "lucide-react";

interface ChatRoom {
  id: string;
  name: string;
  description: string;
  category: string;
  members: number;
  isActive: boolean;
}

interface Message {
  id: string;
  user: string;
  avatar: string;
  message: string;
  timestamp: string;
  likes: number;
  isLiked: boolean;
}

const chatRooms: ChatRoom[] = [
  {
    id: "study-buddies",
    name: "Study Buddies 📚",
    description: "Connect with fellow students and share study tips",
    category: "Academic",
    members: 156,
    isActive: true,
  },
  {
    id: "wellness-warriors",
    name: "Wellness Warriors 🧘‍♀️",
    description: "Discuss mental health, meditation, and self-care",
    category: "Wellness",
    members: 89,
    isActive: true,
  },
  {
    id: "business-minds",
    name: "Young Entrepreneurs 💼",
    description: "Share business ideas and entrepreneurship journey",
    category: "Business",
    members: 67,
    isActive: true,
  },
  {
    id: "creative-corner",
    name: "Creative Corner 🎨",
    description: "Share your art, music, writing, and creative projects",
    category: "Creativity",
    members: 123,
    isActive: true,
  },
];

const sampleMessages: Message[] = [
  {
    id: "1",
    user: "StudyNinja",
    avatar: "S",
    message: "Just finished my chemistry assignment! 🧪 Anyone else studying for the test tomorrow?",
    timestamp: "2 min ago",
    likes: 3,
    isLiked: false,
  },
  {
    id: "2",
    user: "MindfulTeen",
    avatar: "M",
    message: "Remember: progress over perfection! ✨ You've got this!",
    timestamp: "5 min ago",
    likes: 8,
    isLiked: true,
  },
  {
    id: "3",
    user: "FutureFounder",
    avatar: "F",
    message: "Working on my first business plan. Any tips for teen entrepreneurs?",
    timestamp: "12 min ago",
    likes: 5,
    isLiked: false,
  },
  {
    id: "4",
    user: "CreativeSpirit",
    avatar: "C",
    message: "Just finished a digital art piece! Art really helps me relax after studying.",
    timestamp: "18 min ago",
    likes: 12,
    isLiked: false,
  },
];

export default function Community() {
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>(sampleMessages);

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message: Message = {
        id: Date.now().toString(),
        user: "You",
        avatar: "Y",
        message: newMessage,
        timestamp: "now",
        likes: 0,
        isLiked: false,
      };
      setMessages([message, ...messages]);
      setNewMessage("");
    }
  };

  const handleLikeMessage = (messageId: string) => {
    setMessages(messages.map(msg => 
      msg.id === messageId 
        ? { 
            ...msg, 
            likes: msg.isLiked ? msg.likes - 1 : msg.likes + 1,
            isLiked: !msg.isLiked 
          }
        : msg
    ));
  };

  if (selectedRoom) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Button 
            variant="ghost" 
            onClick={() => setSelectedRoom(null)}
            className="mb-6"
          >
            ← Back to Community
          </Button>

          <Card className="h-[600px] flex flex-col">
            <CardHeader className="border-b border-border">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center space-x-2">
                    <span>{selectedRoom.name}</span>
                    <Badge variant="outline" className="text-green-400 border-green-400">
                      {selectedRoom.members} members
                    </Badge>
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    {selectedRoom.description}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm">
                    <Flag className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Shield className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            {/* Messages Area */}
            <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div key={message.id} className="flex space-x-3">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="bg-secondary text-secondary-foreground text-sm">
                      {message.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-medium text-sm">{message.user}</span>
                      <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                    </div>
                    <p className="text-sm text-foreground mb-2">{message.message}</p>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLikeMessage(message.id)}
                        className={`h-6 px-2 ${message.isLiked ? 'text-red-400' : 'text-muted-foreground'}`}
                      >
                        <Heart className={`w-3 h-3 mr-1 ${message.isLiked ? 'fill-current' : ''}`} />
                        {message.likes}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>

            {/* Message Input */}
            <div className="border-t border-border p-4">
              <div className="flex space-x-2">
                <Input
                  placeholder="Type your message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  className="flex-1"
                />
                <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Community 💬</h1>
          <p className="text-muted-foreground mt-2">
            Connect with fellow teens in anonymous, safe chat rooms. Share experiences and support each other!
          </p>
        </div>

        {/* Community Guidelines */}
        <Card className="mb-8 border-blue-400/30 bg-blue-400/5">
          <CardContent className="p-6">
            <div className="flex items-start space-x-3">
              <Shield className="w-6 h-6 text-blue-400 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-blue-400 mb-2">Community Guidelines</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Be respectful and kind to all members</li>
                  <li>• No sharing of personal information (real names, locations, contacts)</li>
                  <li>• Report inappropriate behavior using the flag button</li>
                  <li>• Keep conversations supportive and constructive</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="chat-rooms" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="chat-rooms">Chat Rooms</TabsTrigger>
            <TabsTrigger value="community-feed">Community Feed</TabsTrigger>
          </TabsList>

          <TabsContent value="chat-rooms" className="space-y-6">
            {/* Online Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-green-400/20 rounded-lg">
                      <Users className="w-6 h-6 text-green-400" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Online Now</p>
                      <p className="text-2xl font-bold">247</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-400/20 rounded-lg">
                      <MessageCircle className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Active Rooms</p>
                      <p className="text-2xl font-bold">{chatRooms.filter(r => r.isActive).length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-purple-400/20 rounded-lg">
                      <Heart className="w-6 h-6 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Members</p>
                      <p className="text-2xl font-bold">1,234</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Chat Rooms Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {chatRooms.map((room) => (
                <Card key={room.id} className="card-hover cursor-pointer" onClick={() => setSelectedRoom(room)}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold">{room.name}</h3>
                      <Badge variant="outline" className="text-green-400 border-green-400">
                        {room.members} members
                      </Badge>
                    </div>
                    
                    <p className="text-muted-foreground text-sm mb-4">{room.description}</p>
                    
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{room.category}</Badge>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                        <span>Active</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="community-feed" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Community Feed</CardTitle>
              </CardHeader>
              <CardContent>
                {/* Post something */}
                <div className="border border-border rounded-lg p-4 mb-6">
                  <Textarea
                    placeholder="Share something inspiring with the community..."
                    className="mb-3 resize-none"
                    rows={3}
                  />
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      Your posts are anonymous but moderated for safety
                    </span>
                    <Button size="sm">
                      Share Inspiration
                    </Button>
                  </div>
                </div>

                {/* Feed Posts */}
                <div className="space-y-4">
                  <div className="p-4 border border-border rounded-lg">
                    <div className="flex items-center space-x-2 mb-3">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-purple-400 text-white">A</AvatarFallback>
                      </Avatar>
                      <span className="font-medium">Anonymous User</span>
                      <span className="text-sm text-muted-foreground">2h ago</span>
                    </div>
                    <p className="text-foreground mb-3">
                      Just wanted to share that I finally overcame my fear of public speaking! 
                      The mindfulness course really helped. To anyone struggling with anxiety - you're not alone! 💪✨
                    </p>
                    <div className="flex items-center space-x-4">
                      <Button variant="ghost" size="sm" className="text-red-400">
                        <Heart className="w-4 h-4 mr-1" />
                        23
                      </Button>
                      <Button variant="ghost" size="sm">
                        <MessageCircle className="w-4 h-4 mr-1" />
                        5 replies
                      </Button>
                    </div>
                  </div>

                  <div className="p-4 border border-border rounded-lg">
                    <div className="flex items-center space-x-2 mb-3">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-green-400 text-white">B</AvatarFallback>
                      </Avatar>
                      <span className="font-medium">Growth Seeker</span>
                      <span className="text-sm text-muted-foreground">4h ago</span>
                    </div>
                    <p className="text-foreground mb-3">
                      Day 30 of my reading habit! 📚 Started with just 10 minutes a day and now I can't put books down. 
                      Small consistent steps really do add up!
                    </p>
                    <div className="flex items-center space-x-4">
                      <Button variant="ghost" size="sm" className="text-red-400">
                        <Heart className="w-4 h-4 mr-1" />
                        41
                      </Button>
                      <Button variant="ghost" size="sm">
                        <MessageCircle className="w-4 h-4 mr-1" />
                        12 replies
                      </Button>
                    </div>
                  </div>

                  <div className="p-4 border border-border rounded-lg">
                    <div className="flex items-center space-x-2 mb-3">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-blue-400 text-white">C</AvatarFallback>
                      </Avatar>
                      <span className="font-medium">Dream Chaser</span>
                      <span className="text-sm text-muted-foreground">6h ago</span>
                    </div>
                    <p className="text-foreground mb-3">
                      Reminder: Your pace doesn't matter as long as you don't stop. 
                      Everyone's journey is different. Be patient with yourself! 🌱
                    </p>
                    <div className="flex items-center space-x-4">
                      <Button variant="ghost" size="sm" className="text-red-400">
                        <Heart className="w-4 h-4 mr-1" />
                        67
                      </Button>
                      <Button variant="ghost" size="sm">
                        <MessageCircle className="w-4 h-4 mr-1" />
                        18 replies
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

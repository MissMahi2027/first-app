import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Briefcase, Search, MapPin, DollarSign, Clock, Users, TrendingUp, GraduationCap, Star, ArrowRight, Filter } from "lucide-react";

interface Career {
  id: string;
  title: string;
  category: string;
  description: string;
  averageSalary: string;
  educationRequired: string;
  skills: string[];
  growthRate: string;
  workEnvironment: string;
  personalityTraits: string[];
  relatedCareers: string[];
}

interface Article {
  id: string;
  title: string;
  category: string;
  content: string;
  readTime: string;
  tags: string[];
}

const careerCategories = [
  { id: "all", label: "All Careers", icon: "💼" },
  { id: "technology", label: "Technology", icon: "💻" },
  { id: "healthcare", label: "Healthcare", icon: "🏥" },
  { id: "business", label: "Business", icon: "📊" },
  { id: "creative", label: "Creative Arts", icon: "🎨" },
  { id: "education", label: "Education", icon: "📚" },
  { id: "science", label: "Science", icon: "🔬" },
  { id: "engineering", label: "Engineering", icon: "⚙️" },
  { id: "social", label: "Social Services", icon: "🤝" },
];

const careers: Career[] = [
  {
    id: "software-developer",
    title: "Software Developer",
    category: "technology",
    description: "Design, build, and maintain software applications and systems. Work with programming languages to create solutions for businesses and consumers.",
    averageSalary: "$70,000 - $120,000",
    educationRequired: "Bachelor's degree in Computer Science or related field",
    skills: ["Programming", "Problem-solving", "Teamwork", "Critical thinking", "Continuous learning"],
    growthRate: "22% (Much faster than average)",
    workEnvironment: "Office, remote work options",
    personalityTraits: ["Analytical", "Detail-oriented", "Creative", "Patient"],
    relatedCareers: ["Web Developer", "Data Scientist", "Software Engineer", "Mobile App Developer"],
  },
  {
    id: "graphic-designer",
    title: "Graphic Designer",
    category: "creative",
    description: "Create visual concepts to communicate ideas that inspire, inform, and captivate consumers through digital and print media.",
    averageSalary: "$40,000 - $65,000",
    educationRequired: "Bachelor's degree in Graphic Design or related field",
    skills: ["Creativity", "Adobe Creative Suite", "Typography", "Color theory", "Communication"],
    growthRate: "3% (Slower than average)",
    workEnvironment: "Design studios, advertising agencies, freelance",
    personalityTraits: ["Creative", "Visual", "Innovative", "Detail-oriented"],
    relatedCareers: ["Web Designer", "UX Designer", "Art Director", "Brand Designer"],
  },
  {
    id: "nurse",
    title: "Registered Nurse",
    category: "healthcare",
    description: "Provide and coordinate patient care, educate patients about health conditions, and provide advice and emotional support to patients and families.",
    averageSalary: "$65,000 - $85,000",
    educationRequired: "Bachelor's or Associate degree in Nursing",
    skills: ["Compassion", "Critical thinking", "Communication", "Physical stamina", "Attention to detail"],
    growthRate: "9% (Much faster than average)",
    workEnvironment: "Hospitals, clinics, nursing homes, community health centers",
    personalityTraits: ["Caring", "Empathetic", "Strong", "Dedicated"],
    relatedCareers: ["Nurse Practitioner", "Physical Therapist", "Medical Assistant", "Healthcare Administrator"],
  },
  {
    id: "teacher",
    title: "High School Teacher",
    category: "education",
    description: "Educate students in grades 9-12 in various subjects, develop lesson plans, and assess student progress.",
    averageSalary: "$45,000 - $70,000",
    educationRequired: "Bachelor's degree in education or subject area, teaching license",
    skills: ["Communication", "Patience", "Creativity", "Organization", "Leadership"],
    growthRate: "4% (About as fast as average)",
    workEnvironment: "Public and private schools",
    personalityTraits: ["Patient", "Inspiring", "Organized", "Passionate"],
    relatedCareers: ["Elementary Teacher", "Special Education Teacher", "School Counselor", "Principal"],
  },
  {
    id: "marketing-specialist",
    title: "Marketing Specialist",
    category: "business",
    description: "Research market conditions to examine potential sales of products or services, helping organizations determine what products people want.",
    averageSalary: "$50,000 - $75,000",
    educationRequired: "Bachelor's degree in Marketing, Business, or related field",
    skills: ["Analytical thinking", "Creativity", "Communication", "Digital marketing", "Data analysis"],
    growthRate: "10% (Faster than average)",
    workEnvironment: "Corporate offices, marketing agencies, remote work",
    personalityTraits: ["Strategic", "Creative", "People-oriented", "Adaptable"],
    relatedCareers: ["Digital Marketing Manager", "Social Media Manager", "Brand Manager", "Sales Representative"],
  },
  {
    id: "psychologist",
    title: "Psychologist",
    category: "social",
    description: "Study mental processes and human behavior by observing, interpreting, and recording how people relate to one another and their environments.",
    averageSalary: "$80,000 - $120,000",
    educationRequired: "Doctoral degree in Psychology",
    skills: ["Active listening", "Critical thinking", "Patience", "Problem-solving", "Communication"],
    growthRate: "3% (About as fast as average)",
    workEnvironment: "Private practice, hospitals, schools, research facilities",
    personalityTraits: ["Empathetic", "Analytical", "Patient", "Curious"],
    relatedCareers: ["Counselor", "Social Worker", "Psychiatrist", "Therapist"],
  },
];

const articles: Article[] = [
  {
    id: "interview-tips",
    title: "10 Essential Interview Tips for Teens",
    category: "job-search",
    content: "Preparing for your first job interview can be nerve-wracking, but with the right preparation, you can ace it! Here are essential tips to help you succeed...",
    readTime: "5 min read",
    tags: ["interviews", "job-search", "tips"],
  },
  {
    id: "resume-writing",
    title: "How to Write Your First Resume",
    category: "job-search",
    content: "Even without extensive work experience, you can create a compelling resume that highlights your strengths, skills, and potential...",
    readTime: "8 min read",
    tags: ["resume", "career-prep", "skills"],
  },
  {
    id: "networking",
    title: "Networking for Teens: Building Professional Relationships",
    category: "career-prep",
    content: "Networking isn't just for adults! Learn how to build meaningful professional relationships that can help your career...",
    readTime: "6 min read",
    tags: ["networking", "relationships", "career-growth"],
  },
  {
    id: "college-vs-career",
    title: "College vs. Trade School vs. Starting Your Career",
    category: "education",
    content: "Explore different paths after high school and learn how to choose the right option for your goals and circumstances...",
    readTime: "10 min read",
    tags: ["education", "career-paths", "decision-making"],
  },
  {
    id: "tech-careers",
    title: "Emerging Tech Careers Perfect for Gen Z",
    category: "technology",
    content: "Discover exciting career opportunities in artificial intelligence, cybersecurity, and other cutting-edge technology fields...",
    readTime: "7 min read",
    tags: ["technology", "future-careers", "innovation"],
  },
];

export default function CareerGuidance() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCareer, setSelectedCareer] = useState<Career | null>(null);
  const [articleFilter, setArticleFilter] = useState("all");

  const filteredCareers = careers.filter(career => {
    const matchesCategory = selectedCategory === "all" || career.category === selectedCategory;
    const matchesSearch = career.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         career.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         career.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const filteredArticles = articles.filter(article => {
    return articleFilter === "all" || article.category === articleFilter;
  });

  if (selectedCareer) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Button 
            variant="ghost" 
            onClick={() => setSelectedCareer(null)}
            className="mb-6"
          >
            ← Back to Career Explorer
          </Button>

          <div className="space-y-6">
            {/* Career Header */}
            <Card>
              <CardContent className="p-8">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h1 className="text-3xl font-bold mb-2">{selectedCareer.title}</h1>
                    <Badge variant="outline" className="mb-4">
                      {careerCategories.find(c => c.id === selectedCareer.category)?.icon} {" "}
                      {careerCategories.find(c => c.id === selectedCareer.category)?.label}
                    </Badge>
                    <p className="text-muted-foreground">{selectedCareer.description}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="p-4 bg-green-400/10 rounded-lg">
                    <DollarSign className="w-6 h-6 text-green-400 mb-2" />
                    <p className="text-sm text-muted-foreground">Average Salary</p>
                    <p className="font-semibold">{selectedCareer.averageSalary}</p>
                  </div>
                  
                  <div className="p-4 bg-blue-400/10 rounded-lg">
                    <TrendingUp className="w-6 h-6 text-blue-400 mb-2" />
                    <p className="text-sm text-muted-foreground">Growth Rate</p>
                    <p className="font-semibold">{selectedCareer.growthRate}</p>
                  </div>
                  
                  <div className="p-4 bg-purple-400/10 rounded-lg">
                    <GraduationCap className="w-6 h-6 text-purple-400 mb-2" />
                    <p className="text-sm text-muted-foreground">Education</p>
                    <p className="font-semibold text-sm">{selectedCareer.educationRequired}</p>
                  </div>
                  
                  <div className="p-4 bg-orange-400/10 rounded-lg">
                    <MapPin className="w-6 h-6 text-orange-400 mb-2" />
                    <p className="text-sm text-muted-foreground">Work Environment</p>
                    <p className="font-semibold text-sm">{selectedCareer.workEnvironment}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Career Details */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Required Skills</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {selectedCareer.skills.map((skill) => (
                      <Badge key={skill} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Personality Traits</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {selectedCareer.personalityTraits.map((trait) => (
                      <Badge key={trait} variant="outline">
                        {trait}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Related Careers */}
            <Card>
              <CardHeader>
                <CardTitle>Related Careers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedCareer.relatedCareers.map((career) => (
                    <div key={career} className="p-3 border border-border rounded-lg flex items-center justify-between">
                      <span className="font-medium">{career}</span>
                      <ArrowRight className="w-4 h-4 text-muted-foreground" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Next Steps */}
            <Card>
              <CardHeader>
                <CardTitle>How to Get Started</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-secondary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-medium">1</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Education & Training</h4>
                      <p className="text-sm text-muted-foreground">{selectedCareer.educationRequired}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-secondary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-medium">2</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Develop Key Skills</h4>
                      <p className="text-sm text-muted-foreground">
                        Focus on building: {selectedCareer.skills.slice(0, 3).join(", ")}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-secondary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-medium">3</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Gain Experience</h4>
                      <p className="text-sm text-muted-foreground">
                        Look for internships, volunteer work, or entry-level positions in related fields
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Career Guidance 💼</h1>
          <p className="text-muted-foreground mt-2">
            Explore career paths, discover your interests, and plan your future with confidence.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-400/20 rounded-lg">
                  <Briefcase className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Career Paths</p>
                  <p className="text-2xl font-bold">{careers.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-green-400/20 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">High Growth Jobs</p>
                  <p className="text-2xl font-bold">12</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-purple-400/20 rounded-lg">
                  <GraduationCap className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">No Degree Required</p>
                  <p className="text-2xl font-bold">8</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-orange-400/20 rounded-lg">
                  <Star className="w-6 h-6 text-orange-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Career Articles</p>
                  <p className="text-2xl font-bold">{articles.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="explore" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="explore">Career Explorer</TabsTrigger>
            <TabsTrigger value="articles">Career Articles</TabsTrigger>
            <TabsTrigger value="assessment">Career Assessment</TabsTrigger>
          </TabsList>

          <TabsContent value="explore" className="space-y-6">
            {/* Search and Filter */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      placeholder="Search careers, skills, or job titles..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="flex items-center space-x-2 overflow-x-auto">
                    <Filter className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    {careerCategories.map((category) => (
                      <Button
                        key={category.id}
                        variant={selectedCategory === category.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedCategory(category.id)}
                        className="flex-shrink-0"
                      >
                        <span className="mr-2">{category.icon}</span>
                        {category.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Career Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCareers.map((career) => (
                <Card key={career.id} className="card-hover cursor-pointer" onClick={() => setSelectedCareer(career)}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold mb-2">{career.title}</h3>
                        <Badge variant="outline" className="mb-3">
                          {careerCategories.find(c => c.id === career.category)?.icon} {" "}
                          {careerCategories.find(c => c.id === career.category)?.label}
                        </Badge>
                      </div>
                    </div>
                    
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                      {career.description}
                    </p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-sm">
                        <DollarSign className="w-4 h-4 mr-2 text-green-400" />
                        <span>{career.averageSalary}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <TrendingUp className="w-4 h-4 mr-2 text-blue-400" />
                        <span>{career.growthRate}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {career.skills.slice(0, 3).map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                      {career.skills.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{career.skills.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredCareers.length === 0 && (
              <Card>
                <CardContent className="p-8 text-center">
                  <div className="text-6xl mb-4">🔍</div>
                  <h3 className="text-lg font-semibold mb-2">No careers found</h3>
                  <p className="text-muted-foreground">
                    Try adjusting your search or filter criteria
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="articles" className="space-y-6">
            {/* Article Filter */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2 overflow-x-auto">
                  <span className="text-sm font-medium flex-shrink-0">Category:</span>
                  {["all", "job-search", "career-prep", "education", "technology"].map((filter) => (
                    <Button
                      key={filter}
                      variant={articleFilter === filter ? "default" : "outline"}
                      size="sm"
                      onClick={() => setArticleFilter(filter)}
                      className="flex-shrink-0 capitalize"
                    >
                      {filter.replace("-", " ")}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Articles Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredArticles.map((article) => (
                <Card key={article.id} className="card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <Badge variant="outline">{article.category.replace("-", " ")}</Badge>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Clock className="w-4 h-4 mr-1" />
                        {article.readTime}
                      </div>
                    </div>
                    
                    <h3 className="text-lg font-semibold mb-3">{article.title}</h3>
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                      {article.content}
                    </p>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {article.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <Button variant="outline" className="w-full">
                      Read Article
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="assessment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Career Interest Assessment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <div className="text-6xl mb-4">🧭</div>
                  <h3 className="text-lg font-semibold mb-2">Discover Your Career Path</h3>
                  <p className="text-muted-foreground mb-6">
                    Take our career assessment to discover careers that match your interests, skills, and personality.
                  </p>
                  <Button size="lg">
                    Start Assessment
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Assessment Preview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-3">🎯</div>
                  <h3 className="font-semibold mb-2">Interests</h3>
                  <p className="text-sm text-muted-foreground">
                    Discover what activities and subjects truly engage you
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-3">💪</div>
                  <h3 className="font-semibold mb-2">Skills</h3>
                  <p className="text-sm text-muted-foreground">
                    Identify your natural talents and developed abilities
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-3">🧠</div>
                  <h3 className="font-semibold mb-2">Personality</h3>
                  <p className="text-sm text-muted-foreground">
                    Understand your work style and ideal environment
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, Droplets, Sun, Moon, Calendar, TrendingUp, CheckCircle, AlertCircle } from "lucide-react";

interface SkincareRoutine {
  id: string;
  time: "morning" | "evening";
  steps: SkincareStep[];
}

interface SkincareStep {
  id: string;
  name: string;
  description: string;
  order: number;
  isCompleted: boolean;
  icon: string;
}

interface SkincareProgress {
  date: string;
  morningCompleted: boolean;
  eveningCompleted: boolean;
  mood: "great" | "good" | "okay" | "bad";
  notes?: string;
}

const morningRoutine: SkincareStep[] = [
  {
    id: "1",
    name: "Gentle Cleanser",
    description: "Use a mild, pH-balanced cleanser to remove overnight buildup",
    order: 1,
    isCompleted: true,
    icon: "🧼"
  },
  {
    id: "2",
    name: "Vitamin C Serum",
    description: "Apply antioxidant serum to protect from environmental damage",
    order: 2,
    isCompleted: true,
    icon: "🍊"
  },
  {
    id: "3",
    name: "Moisturizer",
    description: "Hydrate skin with a lightweight, non-comedogenic moisturizer",
    order: 3,
    isCompleted: false,
    icon: "💧"
  },
  {
    id: "4",
    name: "Sunscreen SPF 30+",
    description: "Protect from UV damage - most important step!",
    order: 4,
    isCompleted: false,
    icon: "☀️"
  }
];

const eveningRoutine: SkincareStep[] = [
  {
    id: "1",
    name: "Makeup Remover",
    description: "Remove makeup and sunscreen with gentle oil or micellar water",
    order: 1,
    isCompleted: false,
    icon: "🧴"
  },
  {
    id: "2",
    name: "Double Cleanse",
    description: "Follow up with your regular cleanser for deep clean",
    order: 2,
    isCompleted: false,
    icon: "🧼"
  },
  {
    id: "3",
    name: "Treatment (Optional)",
    description: "Use retinol, BHA, or other treatments 2-3x per week",
    order: 3,
    isCompleted: false,
    icon: "💊"
  },
  {
    id: "4",
    name: "Night Moisturizer",
    description: "Apply a richer moisturizer to repair overnight",
    order: 4,
    isCompleted: false,
    icon: "🌙"
  }
];

const weeklyProgress: SkincareProgress[] = [
  { date: "2024-01-15", morningCompleted: true, eveningCompleted: true, mood: "great" },
  { date: "2024-01-16", morningCompleted: true, eveningCompleted: false, mood: "good" },
  { date: "2024-01-17", morningCompleted: false, eveningCompleted: true, mood: "okay" },
  { date: "2024-01-18", morningCompleted: true, eveningCompleted: true, mood: "great" },
  { date: "2024-01-19", morningCompleted: true, eveningCompleted: true, mood: "good" },
  { date: "2024-01-20", morningCompleted: true, eveningCompleted: false, mood: "good" },
  { date: "2024-01-21", morningCompleted: false, eveningCompleted: false, mood: "okay" },
];

export default function Skincare() {
  const [selectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [morningSteps, setMorningSteps] = useState(morningRoutine);
  const [eveningSteps, setEveningSteps] = useState(eveningRoutine);

  const toggleStep = (stepId: string, routine: "morning" | "evening") => {
    if (routine === "morning") {
      setMorningSteps(steps => 
        steps.map(step => 
          step.id === stepId ? { ...step, isCompleted: !step.isCompleted } : step
        )
      );
    } else {
      setEveningSteps(steps => 
        steps.map(step => 
          step.id === stepId ? { ...step, isCompleted: !step.isCompleted } : step
        )
      );
    }
  };

  const getMoodEmoji = (mood: string) => {
    switch (mood) {
      case "great": return "😊";
      case "good": return "🙂";
      case "okay": return "😐";
      case "bad": return "😞";
      default: return "😐";
    }
  };

  const morningProgress = (morningSteps.filter(s => s.isCompleted).length / morningSteps.length) * 100;
  const eveningProgress = (eveningSteps.filter(s => s.isCompleted).length / eveningSteps.length) * 100;
  const weeklyStreak = weeklyProgress.filter(day => day.morningCompleted && day.eveningCompleted).length;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Skincare Routine ✨</h1>
          <p className="text-muted-foreground mt-2">
            Build healthy skincare habits and track your progress daily.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Sun className="w-8 h-8 text-yellow-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{Math.round(morningProgress)}%</p>
                  <p className="text-sm text-muted-foreground">Morning Routine</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Moon className="w-8 h-8 text-purple-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{Math.round(eveningProgress)}%</p>
                  <p className="text-sm text-muted-foreground">Evening Routine</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <TrendingUp className="w-8 h-8 text-green-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{weeklyStreak}</p>
                  <p className="text-sm text-muted-foreground">Weekly Streak</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Heart className="w-8 h-8 text-pink-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">28</p>
                  <p className="text-sm text-muted-foreground">Days Tracked</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="today" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="today">Today's Routine</TabsTrigger>
            <TabsTrigger value="progress">Weekly Progress</TabsTrigger>
            <TabsTrigger value="tips">Skincare Tips</TabsTrigger>
          </TabsList>

          <TabsContent value="today" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Morning Routine */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Sun className="w-5 h-5 mr-2 text-yellow-400" />
                    Morning Routine
                  </CardTitle>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{Math.round(morningProgress)}%</span>
                    </div>
                    <ProgressBar value={morningProgress} className="h-2" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {morningSteps.map((step) => (
                    <div
                      key={step.id}
                      className={`p-3 border border-border rounded-lg cursor-pointer transition-colors ${
                        step.isCompleted ? 'bg-green-400/10 border-green-400/30' : 'hover:bg-secondary/20'
                      }`}
                      onClick={() => toggleStep(step.id, "morning")}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="text-2xl">{step.icon}</div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <h4 className={`font-medium ${step.isCompleted ? 'line-through text-muted-foreground' : ''}`}>
                              {step.name}
                            </h4>
                            {step.isCompleted && <CheckCircle className="w-4 h-4 text-green-400" />}
                          </div>
                          <p className="text-sm text-muted-foreground">{step.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Evening Routine */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Moon className="w-5 h-5 mr-2 text-purple-400" />
                    Evening Routine
                  </CardTitle>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{Math.round(eveningProgress)}%</span>
                    </div>
                    <ProgressBar value={eveningProgress} className="h-2" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {eveningSteps.map((step) => (
                    <div
                      key={step.id}
                      className={`p-3 border border-border rounded-lg cursor-pointer transition-colors ${
                        step.isCompleted ? 'bg-green-400/10 border-green-400/30' : 'hover:bg-secondary/20'
                      }`}
                      onClick={() => toggleStep(step.id, "evening")}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="text-2xl">{step.icon}</div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <h4 className={`font-medium ${step.isCompleted ? 'line-through text-muted-foreground' : ''}`}>
                              {step.name}
                            </h4>
                            {step.isCompleted && <CheckCircle className="w-4 h-4 text-green-400" />}
                          </div>
                          <p className="text-sm text-muted-foreground">{step.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  Weekly Progress Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {weeklyProgress.map((day, index) => (
                    <div key={day.date} className="flex items-center justify-between p-3 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="text-sm font-medium">
                          Day {index + 1}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(day.date).toLocaleDateString('en-US', { 
                            weekday: 'short', 
                            month: 'short', 
                            day: 'numeric' 
                          })}
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-1">
                          <Sun className={`w-4 h-4 ${day.morningCompleted ? 'text-yellow-400' : 'text-muted-foreground'}`} />
                          {day.morningCompleted && <CheckCircle className="w-3 h-3 text-green-400" />}
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <Moon className={`w-4 h-4 ${day.eveningCompleted ? 'text-purple-400' : 'text-muted-foreground'}`} />
                          {day.eveningCompleted && <CheckCircle className="w-3 h-3 text-green-400" />}
                        </div>
                        
                        <div className="text-lg">
                          {getMoodEmoji(day.mood)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tips" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Droplets className="w-5 h-5 mr-2 text-blue-400" />
                    Teen Skincare Basics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-blue-400/10 rounded-lg">
                    <h4 className="font-medium mb-1">Start Simple</h4>
                    <p className="text-sm text-muted-foreground">
                      Begin with cleanser, moisturizer, and sunscreen. Add products gradually.
                    </p>
                  </div>
                  <div className="p-3 bg-green-400/10 rounded-lg">
                    <h4 className="font-medium mb-1">Be Consistent</h4>
                    <p className="text-sm text-muted-foreground">
                      Results take 4-6 weeks. Stick to your routine even when you don't see immediate changes.
                    </p>
                  </div>
                  <div className="p-3 bg-yellow-400/10 rounded-lg">
                    <h4 className="font-medium mb-1">Patch Test</h4>
                    <p className="text-sm text-muted-foreground">
                      Always test new products on a small area first to check for reactions.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <AlertCircle className="w-5 h-5 mr-2 text-orange-400" />
                    Common Mistakes to Avoid
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-red-400/10 rounded-lg">
                    <h4 className="font-medium mb-1">Over-Cleansing</h4>
                    <p className="text-sm text-muted-foreground">
                      Washing your face more than twice daily can strip natural oils and cause irritation.
                    </p>
                  </div>
                  <div className="p-3 bg-orange-400/10 rounded-lg">
                    <h4 className="font-medium mb-1">Skipping Sunscreen</h4>
                    <p className="text-sm text-muted-foreground">
                      UV protection is crucial even on cloudy days and indoors near windows.
                    </p>
                  </div>
                  <div className="p-3 bg-purple-400/10 rounded-lg">
                    <h4 className="font-medium mb-1">Too Many Products</h4>
                    <p className="text-sm text-muted-foreground">
                      Using too many active ingredients can cause irritation. Introduce one product at a time.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
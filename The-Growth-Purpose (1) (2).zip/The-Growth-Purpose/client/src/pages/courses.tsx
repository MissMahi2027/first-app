import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Clock, Play, CheckCircle, Star, Filter } from "lucide-react";
import { courses, getCoursesByCategory, type Course } from "@/lib/data/courses";
import type { CourseProgress } from "@shared/schema";

export default function Courses() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  const { data: courseProgress = [] } = useQuery<CourseProgress[]>({
    queryKey: ["/api/course-progress"],
  });

  const categories = [
    { id: "all", label: "All Courses", icon: "📚" },
    { id: "productivity", label: "Productivity", icon: "⚡" },
    { id: "wellness", label: "Wellness", icon: "🧘‍♀️" },
    { id: "business", label: "Business", icon: "💼" },
    { id: "personal-development", label: "Personal Growth", icon: "🌱" },
  ];

  const filteredCourses = selectedCategory === "all" 
    ? courses 
    : getCoursesByCategory(selectedCategory);

  const getCourseProgress = (courseId: string) => {
    const progress = courseProgress.find(p => p.courseId === courseId);
    return progress ? (progress.lessonsCompleted / progress.totalLessons) * 100 : 0;
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "text-green-400 border-green-400";
      case "intermediate": return "text-yellow-400 border-yellow-400";
      case "advanced": return "text-red-400 border-red-400";
      default: return "text-gray-400 border-gray-400";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "productivity": return "from-blue-500 to-purple-600";
      case "wellness": return "from-green-500 to-blue-500";
      case "business": return "from-orange-500 to-red-500";
      case "personal-development": return "from-purple-500 to-pink-500";
      default: return "from-gray-500 to-gray-600";
    }
  };

  if (selectedCourse) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Button 
            variant="ghost" 
            onClick={() => setSelectedCourse(null)}
            className="mb-6"
          >
            ← Back to Courses
          </Button>

          <div className="space-y-6">
            {/* Course Header */}
            <Card>
              <CardContent className="p-8">
                <div className="flex items-start space-x-4">
                  <div className="text-6xl">{selectedCourse.icon}</div>
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold mb-2">{selectedCourse.title}</h1>
                    <p className="text-muted-foreground mb-4">{selectedCourse.description}</p>
                    
                    <div className="flex items-center space-x-4 mb-4">
                      <Badge variant="outline" className={getDifficultyColor(selectedCourse.difficulty)}>
                        {selectedCourse.difficulty}
                      </Badge>
                      <span className="flex items-center text-sm text-muted-foreground">
                        <Clock className="w-4 h-4 mr-1" />
                        {selectedCourse.estimatedHours} hours
                      </span>
                      <span className="flex items-center text-sm text-muted-foreground">
                        <BookOpen className="w-4 h-4 mr-1" />
                        {selectedCourse.totalLessons} lessons
                      </span>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{Math.round(getCourseProgress(selectedCourse.id))}%</span>
                      </div>
                      <ProgressBar value={getCourseProgress(selectedCourse.id)} className="h-2" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Course Lessons */}
            <Card>
              <CardHeader>
                <CardTitle>Course Lessons</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {selectedCourse.lessons.map((lesson, index) => (
                    <div key={lesson.id} className="p-4 border border-border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center text-sm font-medium">
                            {index + 1}
                          </div>
                          <div>
                            <h3 className="font-medium">{lesson.title}</h3>
                            <p className="text-sm text-muted-foreground">
                              {lesson.estimatedMinutes} minutes • {lesson.type}
                            </p>
                          </div>
                        </div>
                        <Button size="sm">
                          <Play className="w-4 h-4 mr-2" />
                          Start
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Growth Courses 🎓</h1>
          <p className="text-muted-foreground mt-2">
            Learn new skills and develop yourself with our curated courses designed for teenagers.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-400/20 rounded-lg">
                  <BookOpen className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Available Courses</p>
                  <p className="text-2xl font-bold">{courses.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-green-400/20 rounded-lg">
                  <CheckCircle className="w-6 h-6 text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-2xl font-bold">{courseProgress.filter(p => p.isCompleted).length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-purple-400/20 rounded-lg">
                  <Play className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">In Progress</p>
                  <p className="text-2xl font-bold">{courseProgress.filter(p => !p.isCompleted && p.lessonsCompleted > 0).length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-yellow-400/20 rounded-lg">
                  <Star className="w-6 h-6 text-yellow-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Hours</p>
                  <p className="text-2xl font-bold">{courses.reduce((sum, c) => sum + c.estimatedHours, 0)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="all-courses" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="all-courses">All Courses</TabsTrigger>
            <TabsTrigger value="my-progress">My Progress</TabsTrigger>
          </TabsList>

          <TabsContent value="all-courses" className="space-y-6">
            {/* Category Filter */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2 overflow-x-auto">
                  <Filter className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  {categories.map((category) => (
                    <Button
                      key={category.id}
                      variant={selectedCategory === category.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedCategory(category.id)}
                      className="flex-shrink-0"
                    >
                      <span className="mr-2">{category.icon}</span>
                      {category.label}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Courses Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCourses.map((course) => {
                const progress = getCourseProgress(course.id);
                const isStarted = progress > 0;
                const isCompleted = progress >= 100;

                return (
                  <Card key={course.id} className="overflow-hidden card-hover cursor-pointer" onClick={() => setSelectedCourse(course)}>
                    <div className={`h-48 bg-gradient-to-br ${getCategoryColor(course.category)} flex items-center justify-center relative`}>
                      <div className="text-white text-6xl">{course.icon}</div>
                      {isCompleted && (
                        <div className="absolute top-4 right-4 bg-green-400 text-white rounded-full p-1">
                          <CheckCircle className="w-5 h-5" />
                        </div>
                      )}
                    </div>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline" className={getDifficultyColor(course.difficulty)}>
                          {course.difficulty}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {course.estimatedHours}h • {course.totalLessons} lessons
                        </span>
                      </div>
                      
                      <h3 className="text-lg font-semibold mb-2">{course.title}</h3>
                      <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                        {course.description}
                      </p>

                      {isStarted && (
                        <div className="space-y-2 mb-4">
                          <div className="flex justify-between text-sm">
                            <span>Progress</span>
                            <span>{Math.round(progress)}%</span>
                          </div>
                          <ProgressBar value={progress} className="h-2" />
                        </div>
                      )}

                      <Button className="w-full" onClick={(e) => { e.stopPropagation(); setSelectedCourse(course); }}>
                        {isCompleted ? "Review" : isStarted ? "Continue" : "Start Course"}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="my-progress" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>My Learning Progress</CardTitle>
              </CardHeader>
              <CardContent>
                {courseProgress.length === 0 ? (
                  <div className="text-center py-8">
                    <div className="text-6xl mb-4">📚</div>
                    <h3 className="text-lg font-semibold mb-2">No courses started yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Start your first course to begin tracking your progress!
                    </p>
                    <Button onClick={() => setSelectedCategory("all")}>
                      Browse Courses
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {courseProgress.map((progress) => {
                      const course = courses.find(c => c.id === progress.courseId);
                      if (!course) return null;

                      const completionPercentage = (progress.lessonsCompleted / progress.totalLessons) * 100;

                      return (
                        <div key={progress.id} className="p-4 border border-border rounded-lg">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <span className="text-2xl">{course.icon}</span>
                              <div>
                                <h3 className="font-semibold">{course.title}</h3>
                                <p className="text-sm text-muted-foreground">
                                  {progress.lessonsCompleted} of {progress.totalLessons} lessons completed
                                </p>
                              </div>
                            </div>
                            {progress.isCompleted && (
                              <Badge className="bg-green-400 text-white">
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Completed
                              </Badge>
                            )}
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Progress</span>
                              <span>{Math.round(completionPercentage)}%</span>
                            </div>
                            <ProgressBar value={completionPercentage} className="h-2" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

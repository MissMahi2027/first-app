import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Star, Heart, MessageCircle, Send } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface FeedbackData {
  rating: number;
  category: string;
  message: string;
  feature?: string;
}

export default function Feedback() {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [category, setCategory] = useState("");
  const [feature, setFeature] = useState("");
  const [message, setMessage] = useState("");
  const { toast } = useToast();

  const submitFeedback = useMutation({
    mutationFn: async (data: FeedbackData) => {
      return await apiRequest("/api/feedback", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Thank you for your feedback!",
        description: "Your input helps us improve The Growth Purpose for everyone.",
      });
      // Reset form
      setRating(0);
      setCategory("");
      setFeature("");
      setMessage("");
    },
    onError: () => {
      toast({
        title: "Something went wrong",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0 || !category || !message.trim()) {
      toast({
        title: "Please fill all required fields",
        description: "Rating, category, and message are required.",
        variant: "destructive",
      });
      return;
    }

    submitFeedback.mutate({
      rating,
      category,
      message,
      feature: feature || undefined,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-fadeIn">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-4">
              Share Your Feedback
            </h1>
            <p className="text-muted-foreground">
              Help us make The Growth Purpose even better for you and our community
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="card-hover transition-all animate-slideIn">
              <CardContent className="p-6 text-center">
                <Heart className="w-8 h-8 text-purple-500 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Love Something?</h3>
                <p className="text-sm text-muted-foreground">
                  Tell us what features you enjoy most
                </p>
              </CardContent>
            </Card>

            <Card className="card-hover transition-all animate-slideIn" style={{ animationDelay: '0.1s' }}>
              <CardContent className="p-6 text-center">
                <MessageCircle className="w-8 h-8 text-blue-500 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Suggestions</h3>
                <p className="text-sm text-muted-foreground">
                  Share ideas for new features or improvements
                </p>
              </CardContent>
            </Card>

            <Card className="card-hover transition-all animate-slideIn" style={{ animationDelay: '0.2s' }}>
              <CardContent className="p-6 text-center">
                <Star className="w-8 h-8 text-yellow-500 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Rate Experience</h3>
                <p className="text-sm text-muted-foreground">
                  Let us know how we're doing overall
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="animate-fadeIn" style={{ animationDelay: '0.3s' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-purple-500" />
                Your Feedback
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Rating Section */}
                <div className="space-y-2">
                  <Label className="text-base font-medium">Overall Rating *</Label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoveredRating(star)}
                        onMouseLeave={() => setHoveredRating(0)}
                        className="p-1 hover-lift transition-all"
                      >
                        <Star
                          className={`w-8 h-8 transition-colors ${
                            star <= (hoveredRating || rating)
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {rating === 0 && "Click to rate your experience"}
                    {rating === 1 && "Poor - Needs significant improvement"}
                    {rating === 2 && "Fair - Some areas need work"}
                    {rating === 3 && "Good - Generally satisfied"}
                    {rating === 4 && "Very Good - Mostly positive experience"}
                    {rating === 5 && "Excellent - Exceeded expectations"}
                  </p>
                </div>

                {/* Category Selection */}
                <div className="space-y-2">
                  <Label htmlFor="category" className="text-base font-medium">Feedback Category *</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General Experience</SelectItem>
                      <SelectItem value="features">Feature Request</SelectItem>
                      <SelectItem value="bug">Bug Report</SelectItem>
                      <SelectItem value="ui">User Interface</SelectItem>
                      <SelectItem value="performance">Performance</SelectItem>
                      <SelectItem value="content">Content Quality</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Specific Feature */}
                <div className="space-y-2">
                  <Label htmlFor="feature" className="text-base font-medium">Specific Feature (Optional)</Label>
                  <Select value={feature} onValueChange={setFeature}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a feature" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dashboard">Dashboard</SelectItem>
                      <SelectItem value="habits">Habit Tracker</SelectItem>
                      <SelectItem value="journal">Journal</SelectItem>
                      <SelectItem value="courses">Growth Courses</SelectItem>
                      <SelectItem value="community">Community</SelectItem>
                      <SelectItem value="career">Career Guidance</SelectItem>
                      <SelectItem value="pomodoro">Pomodoro Timer</SelectItem>
                      <SelectItem value="motivation">Motivation Wall</SelectItem>
                      <SelectItem value="progress">Progress Analytics</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Message */}
                <div className="space-y-2">
                  <Label htmlFor="message" className="text-base font-medium">Your Message *</Label>
                  <Textarea
                    id="message"
                    placeholder="Share your thoughts, suggestions, or report any issues..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    rows={5}
                    className="resize-none"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={submitFeedback.isPending}
                  className="w-full hover-lift transition-all"
                  size="lg"
                >
                  {submitFeedback.isPending ? (
                    <>Sending...</>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Send Feedback
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Thank You Section */}
          <Card className="mt-8 animate-fadeIn" style={{ animationDelay: '0.5s' }}>
            <CardContent className="p-6 text-center">
              <h3 className="font-semibold mb-2">Thank You for Helping Us Grow! 🌱</h3>
              <p className="text-sm text-muted-foreground">
                Every piece of feedback helps us create a better experience for our community.
                We read every message and use your input to guide our development priorities.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
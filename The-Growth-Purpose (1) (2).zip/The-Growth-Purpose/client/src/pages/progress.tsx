import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, LineChart, TrendingUp, Target, Calendar, Award } from "lucide-react";
import type { Habit, HabitLog, PomodoroSession, Goal } from "@shared/schema";

interface WeeklyData {
  day: string;
  habits: number;
  focusTime: number;
  goals: number;
}

export default function Progress() {
  const { data: habits = [] } = useQuery<Habit[]>({
    queryKey: ["/api/habits"],
  });

  const { data: goals = [] } = useQuery<Goal[]>({
    queryKey: ["/api/goals"],
  });

  const today = new Date().toISOString().split('T')[0];
  const { data: pomodoroSessions = [] } = useQuery<PomodoroSession[]>({
    queryKey: ["/api/pomodoro", { date: today }],
  });

  // Generate weekly data for charts
  const getWeeklyData = (): WeeklyData[] => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return days.map((day, index) => ({
      day,
      habits: Math.floor(Math.random() * habits.length) + 1, // Mock data for demo
      focusTime: Math.floor(Math.random() * 180) + 30, // Mock data for demo
      goals: Math.floor(Math.random() * 5) + 1, // Mock data for demo
    }));
  };

  const weeklyData = getWeeklyData();
  const maxHabits = Math.max(...weeklyData.map(d => d.habits));
  const maxFocusTime = Math.max(...weeklyData.map(d => d.focusTime));
  const maxGoals = Math.max(...weeklyData.map(d => d.goals));

  const totalFocusTime = pomodoroSessions
    .filter(s => s.completed)
    .reduce((total, s) => total + s.duration, 0);

  const completedGoals = goals.filter(g => g.isCompleted).length;
  const totalGoals = goals.length;
  const goalCompletionRate = totalGoals > 0 ? (completedGoals / totalGoals) * 100 : 0;

  const longestStreak = Math.max(...habits.map(h => h.longestStreak || 0), 0);
  const activeHabits = habits.filter(h => h.isActive).length;

  const statsCards = [
    {
      title: "Goal Completion Rate",
      value: `${Math.round(goalCompletionRate)}%`,
      change: "+12% from last week",
      icon: Target,
      color: "text-green-400",
    },
    {
      title: "Longest Habit Streak",
      value: `${longestStreak} days`,
      change: "Keep it going!",
      icon: Award,
      color: "text-orange-400",
    },
    {
      title: "Weekly Focus Time",
      value: `${Math.floor(totalFocusTime / 60)}h ${totalFocusTime % 60}m`,
      change: "+2.5h from last week",
      icon: TrendingUp,
      color: "text-blue-400",
    },
    {
      title: "Active Habits",
      value: activeHabits.toString(),
      change: "Consistency is key",
      icon: Calendar,
      color: "text-purple-400",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Progress Tracker 📊</h1>
          <p className="text-muted-foreground mt-2">
            Track your growth journey with detailed analytics and insights.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statsCards.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <Card key={index} className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-muted-foreground text-sm">{stat.title}</span>
                    <IconComponent className={`w-5 h-5 ${stat.color}`} />
                  </div>
                  <div className="text-2xl font-bold text-foreground mb-1">{stat.value}</div>
                  <div className={`text-sm ${stat.color}`}>{stat.change}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="weekly" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="weekly">Weekly View</TabsTrigger>
            <TabsTrigger value="habits">Habit Analysis</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          <TabsContent value="weekly" className="space-y-6">
            {/* Weekly Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Habits Completed Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart className="w-5 h-5 mr-2" />
                    Daily Habits Completed
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {weeklyData.map((day) => (
                      <div key={day.day} className="flex items-center space-x-3">
                        <span className="text-sm font-medium w-8">{day.day}</span>
                        <div className="flex-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span>{day.habits} habits</span>
                            <span>{Math.round((day.habits / maxHabits) * 100)}%</span>
                          </div>
                          <ProgressBar value={(day.habits / maxHabits) * 100} className="h-2" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Focus Time Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <LineChart className="w-5 h-5 mr-2" />
                    Daily Focus Time
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {weeklyData.map((day) => (
                      <div key={day.day} className="flex items-center space-x-3">
                        <span className="text-sm font-medium w-8">{day.day}</span>
                        <div className="flex-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span>{day.focusTime}min</span>
                            <span>{Math.round((day.focusTime / maxFocusTime) * 100)}%</span>
                          </div>
                          <ProgressBar 
                            value={(day.focusTime / maxFocusTime) * 100} 
                            className="h-2"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Weekly Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Weekly Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-4 bg-green-400/10 rounded-lg">
                    <div className="text-2xl font-bold text-green-400 mb-1">
                      {weeklyData.reduce((sum, day) => sum + day.habits, 0)}
                    </div>
                    <div className="text-sm text-muted-foreground">Total Habits Completed</div>
                  </div>
                  <div className="text-center p-4 bg-blue-400/10 rounded-lg">
                    <div className="text-2xl font-bold text-blue-400 mb-1">
                      {Math.floor(weeklyData.reduce((sum, day) => sum + day.focusTime, 0) / 60)}h
                    </div>
                    <div className="text-sm text-muted-foreground">Total Focus Time</div>
                  </div>
                  <div className="text-center p-4 bg-purple-400/10 rounded-lg">
                    <div className="text-2xl font-bold text-purple-400 mb-1">
                      {weeklyData.reduce((sum, day) => sum + day.goals, 0)}
                    </div>
                    <div className="text-sm text-muted-foreground">Goals Achieved</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="habits" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Habit Performance</CardTitle>
              </CardHeader>
              <CardContent>
                {habits.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No habits to analyze yet.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {habits.map((habit) => (
                      <div key={habit.id} className="p-4 border border-border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-3">
                            <span className="text-xl">{habit.icon}</span>
                            <div>
                              <h3 className="font-medium">{habit.title}</h3>
                              <p className="text-sm text-muted-foreground">
                                Current streak: {habit.currentStreak || 0} days
                              </p>
                            </div>
                          </div>
                          <Badge variant="outline">
                            Best: {habit.longestStreak || 0} days
                          </Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Consistency Score</span>
                            <span>{Math.round(((habit.currentStreak || 0) / 30) * 100)}%</span>
                          </div>
                          <ProgressBar 
                            value={Math.min(((habit.currentStreak || 0) / 30) * 100, 100)} 
                            className="h-2"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Your Achievements 🏆</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {/* Achievement Badges */}
                  <div className="p-4 bg-gradient-to-br from-yellow-400/20 to-orange-400/20 rounded-lg border border-yellow-400/30">
                    <div className="text-3xl mb-2">🔥</div>
                    <h3 className="font-semibold text-yellow-400">Streak Master</h3>
                    <p className="text-sm text-muted-foreground">Achieved a 7-day habit streak</p>
                  </div>

                  <div className="p-4 bg-gradient-to-br from-green-400/20 to-blue-400/20 rounded-lg border border-green-400/30">
                    <div className="text-3xl mb-2">🎯</div>
                    <h3 className="font-semibold text-green-400">Goal Crusher</h3>
                    <p className="text-sm text-muted-foreground">Completed 10 goals this month</p>
                  </div>

                  <div className="p-4 bg-gradient-to-br from-purple-400/20 to-pink-400/20 rounded-lg border border-purple-400/30">
                    <div className="text-3xl mb-2">⏰</div>
                    <h3 className="font-semibold text-purple-400">Focus Champion</h3>
                    <p className="text-sm text-muted-foreground">20+ hours of focus time</p>
                  </div>

                  <div className="p-4 bg-gradient-to-br from-blue-400/20 to-cyan-400/20 rounded-lg border border-blue-400/30">
                    <div className="text-3xl mb-2">📚</div>
                    <h3 className="font-semibold text-blue-400">Lifelong Learner</h3>
                    <p className="text-sm text-muted-foreground">Completed 3 courses</p>
                  </div>

                  <div className="p-4 bg-gradient-to-br from-red-400/20 to-orange-400/20 rounded-lg border border-red-400/30">
                    <div className="text-3xl mb-2">💪</div>
                    <h3 className="font-semibold text-red-400">Consistency King</h3>
                    <p className="text-sm text-muted-foreground">30-day challenge complete</p>
                  </div>

                  <div className="p-4 bg-gradient-to-br from-indigo-400/20 to-purple-400/20 rounded-lg border border-indigo-400/30">
                    <div className="text-3xl mb-2">✨</div>
                    <h3 className="font-semibold text-indigo-400">Rising Star</h3>
                    <p className="text-sm text-muted-foreground">First week completed!</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

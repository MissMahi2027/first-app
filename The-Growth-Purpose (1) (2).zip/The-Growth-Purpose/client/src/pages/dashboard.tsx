import { useQuery } from "@tanstack/react-query";
import StatsCards from "@/components/dashboard/stats-cards";
import MotivationCard from "@/components/dashboard/motivation-card";
import ProgressTracker from "@/components/dashboard/progress-tracker";
import HabitsWidget from "@/components/dashboard/habits-widget";
import PomodoroTimer from "@/components/dashboard/pomodoro-timer";
import QuickJournal from "@/components/dashboard/quick-journal";
import FeatureGrid from "@/components/dashboard/feature-grid";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, Target, Trophy } from "lucide-react";
import { Link } from "wouter";
import type { User, Goal } from "@shared/schema";

export default function Dashboard() {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  const { data: todayGoals = [] } = useQuery<Goal[]>({
    queryKey: ["/api/goals/today"],
  });

  const currentHour = new Date().getHours();
  const greeting = currentHour < 12 ? "Good morning" : currentHour < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <section className="mb-8 animate-fade-in">
          <div className="gradient-primary rounded-xl p-6 text-white relative overflow-hidden">
            <div className="relative z-10">
              <h1 className="text-2xl md:text-3xl font-bold mb-2">
                {greeting}, {user?.name || 'Friend'}! 🌅
              </h1>
              <p className="text-blue-100 mb-4">
                Ready to grow today? You have {todayGoals.filter(g => !g.isCompleted).length} goals to complete today.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button variant="secondary" className="bg-white text-primary hover:bg-blue-50">
                  <Target className="w-4 h-4 mr-2" />
                  View Today's Goals
                </Button>
                <Button variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                  <Clock className="w-4 h-4 mr-2" />
                  Start Focus Session
                </Button>
              </div>
            </div>
            <div className="absolute top-0 right-0 w-32 h-32 bg-white bg-opacity-10 rounded-full -mr-16 -mt-16"></div>
          </div>
        </section>

        {/* Stats Cards */}
        <StatsCards />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            <MotivationCard />
            <ProgressTracker />
            
            {/* Productivity Tools */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  🛠️ Productivity Tools
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <PomodoroTimer />
                  
                  {/* Quick Todo */}
                  <div className="bg-secondary/20 rounded-lg p-4">
                    <div className="text-3xl mb-2 text-center">📝</div>
                    <h3 className="font-semibold mb-2 text-center">Quick Todo</h3>
                    <input
                      type="text"
                      placeholder="Add a quick task..."
                      className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-sm mb-2 focus:outline-none focus:ring-2 focus:ring-secondary"
                    />
                    <Button className="w-full text-sm">
                      Add Task
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-8">
            <HabitsWidget />
            <QuickJournal />
            
            {/* Upcoming Events */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  📅 Upcoming
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-yellow-400/10 rounded-lg border-l-4 border-yellow-400">
                  <div className="text-yellow-400">⏰</div>
                  <div>
                    <div className="text-sm font-medium">Math Study Session</div>
                    <div className="text-xs text-muted-foreground">Today, 3:00 PM</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-green-400/10 rounded-lg border-l-4 border-green-400">
                  <div className="text-green-400">🎯</div>
                  <div>
                    <div className="text-sm font-medium">Weekly Challenge</div>
                    <div className="text-xs text-muted-foreground">Ends in 3 days</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-purple-400/10 rounded-lg border-l-4 border-purple-400">
                  <div className="text-purple-400">📚</div>
                  <div>
                    <div className="text-sm font-medium">Course Deadline</div>
                    <div className="text-xs text-muted-foreground">Tomorrow, 11:59 PM</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Feature Navigation Grid */}
        <FeatureGrid />

        {/* Course Highlights */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">🎓 Featured Growth Courses</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Course Card 1 */}
            <Card className="overflow-hidden card-hover">
              <div className="h-48 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <div className="text-white text-6xl">📚</div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Study Smart, Not Hard</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Learn effective study techniques and time management strategies for academic success.
                </p>
                <div className="flex items-center justify-between">
                  <div className="text-secondary text-sm">12 lessons • 3 hours</div>
                  <Link href="/courses">
                    <Button size="sm">Start</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Course Card 2 */}
            <Card className="overflow-hidden card-hover">
              <div className="h-48 bg-gradient-to-br from-green-500 to-blue-500 flex items-center justify-center">
                <div className="text-white text-6xl">🧘‍♀️</div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Mindfulness for Teens</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Discover meditation, stress relief, and emotional balance techniques designed for young adults.
                </p>
                <div className="flex items-center justify-between">
                  <div className="text-secondary text-sm">8 lessons • 2 hours</div>
                  <Link href="/courses">
                    <Button size="sm">Start</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Course Card 3 */}
            <Card className="overflow-hidden card-hover">
              <div className="h-48 bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
                <div className="text-white text-6xl">💼</div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Teen Entrepreneur Basics</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Learn the fundamentals of starting your own business as a teenager with practical tips.
                </p>
                <div className="flex items-center justify-between">
                  <div className="text-secondary text-sm">15 lessons • 4 hours</div>
                  <Link href="/courses">
                    <Button size="sm">Start</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

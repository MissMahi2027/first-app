import { useState } from "react";
import { useJournal, useTodayJournalEntry } from "@/hooks/use-journal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, BookOpen, Calendar, Heart, Smile, Meh, Frown, Search, Filter } from "lucide-react";
import { format } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import type { InsertJournalEntry } from "@shared/schema";

const journalSchema = z.object({
  title: z.string().optional(),
  content: z.string().min(1, "Content is required"),
  mood: z.string().optional(),
  tags: z.array(z.string()).optional(),
  date: z.string().min(1, "Date is required"),
});

type JournalFormData = z.infer<typeof journalSchema>;

const moodOptions = [
  { value: "amazing", label: "Amazing", icon: "🤩", color: "text-green-400" },
  { value: "happy", label: "Happy", icon: "😊", color: "text-blue-400" },
  { value: "good", label: "Good", icon: "🙂", color: "text-yellow-400" },
  { value: "neutral", label: "Neutral", icon: "😐", color: "text-gray-400" },
  { value: "down", label: "Down", icon: "😔", color: "text-orange-400" },
  { value: "sad", label: "Sad", icon: "😢", color: "text-red-400" },
];

const commonTags = [
  "gratitude", "reflection", "goals", "achievements", "challenges", 
  "learning", "relationships", "school", "work", "health", "creativity", "thoughts"
];

const journalPrompts = [
  "What am I most grateful for today?",
  "What did I learn about myself today?",
  "What challenge did I overcome?",
  "What made me smile today?",
  "How did I grow today?",
  "What would I tell my past self?",
  "What are three things that went well?",
  "What am I looking forward to?",
  "How did I help someone today?",
  "What new perspective did I gain?",
];

export default function Journal() {
  const { entries, createEntry, isCreating } = useJournal();
  const { todayEntry, saveEntry, isSaving } = useTodayJournalEntry();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMoodFilter, setSelectedMoodFilter] = useState<string>("all");
  const [quickNote, setQuickNote] = useState("");

  const form = useForm<JournalFormData>({
    resolver: zodResolver(journalSchema),
    defaultValues: {
      title: "",
      content: "",
      mood: "neutral",
      tags: [],
      date: format(new Date(), "yyyy-MM-dd"),
    },
  });

  const onSubmit = (data: JournalFormData) => {
    createEntry({
      ...data,
      tags: selectedTags,
    });
    setIsDialogOpen(false);
    setSelectedTags([]);
    form.reset();
  };

  const toggleTag = (tag: string) => {
    setSelectedTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  const getMoodIcon = (mood: string) => {
    const moodOption = moodOptions.find(m => m.value === mood);
    return moodOption ? moodOption.icon : "😐";
  };

  const getMoodColor = (mood: string) => {
    const moodOption = moodOptions.find(m => m.value === mood);
    return moodOption ? moodOption.color : "text-gray-400";
  };

  const filteredEntries = entries.filter(entry => {
    const matchesSearch = entry.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesMood = selectedMoodFilter === "all" || entry.mood === selectedMoodFilter;
    return matchesSearch && matchesMood;
  });

  const handleQuickSave = () => {
    if (quickNote.trim()) {
      saveEntry(quickNote);
      setQuickNote("");
    }
  };

  const today = format(new Date(), "yyyy-MM-dd");

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Journal 📖</h1>
            <p className="text-muted-foreground mt-2">
              Reflect on your journey, capture your thoughts, and track your growth.
            </p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                New Entry
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create Journal Entry</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="Give your entry a title..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="mood"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How are you feeling?</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your mood" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {moodOptions.map((mood) => (
                              <SelectItem key={mood.value} value={mood.value}>
                                <div className="flex items-center space-x-2">
                                  <span>{mood.icon}</span>
                                  <span>{mood.label}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="content"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>What's on your mind?</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Write about your day, thoughts, feelings, or experiences..."
                            {...field}
                            rows={8}
                            className="resize-none"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div>
                    <Label className="text-sm font-medium">Tags</Label>
                    <p className="text-sm text-muted-foreground mb-3">
                      Add tags to organize your entries
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {commonTags.map((tag) => (
                        <Badge
                          key={tag}
                          variant={selectedTags.includes(tag) ? "default" : "outline"}
                          className="cursor-pointer"
                          onClick={() => toggleTag(tag)}
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex space-x-2 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      className="flex-1"
                      onClick={() => setIsDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      className="flex-1"
                      disabled={isCreating}
                    >
                      {isCreating ? "Saving..." : "Save Entry"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="today" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="today">Today's Entry</TabsTrigger>
                <TabsTrigger value="all">All Entries</TabsTrigger>
                <TabsTrigger value="prompts">Writing Prompts</TabsTrigger>
              </TabsList>

              <TabsContent value="today" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Calendar className="w-5 h-5 mr-2" />
                      Today's Reflection - {format(new Date(), "MMMM d, yyyy")}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {todayEntry ? (
                      <div className="space-y-4">
                        <div className="flex items-center space-x-2 mb-3">
                          <span className="text-2xl">{getMoodIcon(todayEntry.mood || "neutral")}</span>
                          <span className={`font-medium ${getMoodColor(todayEntry.mood || "neutral")}`}>
                            {moodOptions.find(m => m.value === todayEntry.mood)?.label || "Neutral"}
                          </span>
                        </div>
                        {todayEntry.title && (
                          <h3 className="text-lg font-semibold">{todayEntry.title}</h3>
                        )}
                        <div className="prose prose-sm max-w-none text-foreground">
                          <p className="whitespace-pre-wrap">{todayEntry.content}</p>
                        </div>
                        {todayEntry.tags && todayEntry.tags.length > 0 && (
                          <div className="flex flex-wrap gap-2">
                            {todayEntry.tags.map((tag) => (
                              <Badge key={tag} variant="secondary">{tag}</Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="text-center py-8">
                          <div className="text-6xl mb-4">✍️</div>
                          <h3 className="text-lg font-semibold mb-2">No entry for today yet</h3>
                          <p className="text-muted-foreground mb-4">
                            Take a moment to reflect on your day
                          </p>
                        </div>
                        
                        <div className="border-t border-border pt-4">
                          <Label className="text-sm font-medium">Quick Note</Label>
                          <Textarea
                            placeholder="How are you feeling today? What went well?"
                            value={quickNote}
                            onChange={(e) => setQuickNote(e.target.value)}
                            rows={4}
                            className="mt-2 resize-none"
                          />
                          <div className="flex justify-between items-center mt-3">
                            <span className="text-sm text-muted-foreground">
                              Write a quick reflection for today
                            </span>
                            <Button
                              onClick={handleQuickSave}
                              disabled={!quickNote.trim() || isSaving}
                              size="sm"
                            >
                              {isSaving ? "Saving..." : "Save Entry"}
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="all" className="space-y-6">
                {/* Search and Filter */}
                <Card>
                  <CardContent className="p-4">
                    <div className="flex flex-col sm:flex-row gap-4">
                      <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                        <Input
                          placeholder="Search entries..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                      <Select value={selectedMoodFilter} onValueChange={setSelectedMoodFilter}>
                        <SelectTrigger className="w-40">
                          <Filter className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Filter by mood" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All moods</SelectItem>
                          {moodOptions.map((mood) => (
                            <SelectItem key={mood.value} value={mood.value}>
                              <div className="flex items-center space-x-2">
                                <span>{mood.icon}</span>
                                <span>{mood.label}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>

                {/* Entries List */}
                <div className="space-y-4">
                  {filteredEntries.length === 0 ? (
                    <Card>
                      <CardContent className="p-8 text-center">
                        <div className="text-6xl mb-4">📝</div>
                        <h3 className="text-lg font-semibold mb-2">
                          {entries.length === 0 ? "No journal entries yet" : "No entries match your search"}
                        </h3>
                        <p className="text-muted-foreground mb-4">
                          {entries.length === 0 
                            ? "Start journaling to track your thoughts and growth"
                            : "Try adjusting your search or filter criteria"
                          }
                        </p>
                        {entries.length === 0 && (
                          <Button onClick={() => setIsDialogOpen(true)}>
                            <Plus className="w-4 h-4 mr-2" />
                            Create Your First Entry
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  ) : (
                    filteredEntries.map((entry) => (
                      <Card key={entry.id} className="card-hover">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <span className="text-xl">{getMoodIcon(entry.mood || "neutral")}</span>
                              <div>
                                <h3 className="font-semibold">
                                  {entry.title || `Entry for ${format(new Date(entry.date), "MMMM d, yyyy")}`}
                                </h3>
                                <p className="text-sm text-muted-foreground">
                                  {format(new Date(entry.date), "MMMM d, yyyy")}
                                </p>
                              </div>
                            </div>
                            <Badge variant="outline" className={getMoodColor(entry.mood || "neutral")}>
                              {moodOptions.find(m => m.value === entry.mood)?.label || "Neutral"}
                            </Badge>
                          </div>
                          
                          <div className="prose prose-sm max-w-none text-foreground mb-4">
                            <p className="line-clamp-3">{entry.content}</p>
                          </div>

                          {entry.tags && entry.tags.length > 0 && (
                            <div className="flex flex-wrap gap-2">
                              {entry.tags.map((tag) => (
                                <Badge key={tag} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </TabsContent>

              <TabsContent value="prompts" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <BookOpen className="w-5 h-5 mr-2" />
                      Writing Prompts
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-6">
                      Stuck on what to write? Try one of these prompts to get started!
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {journalPrompts.map((prompt, index) => (
                        <Card key={index} className="card-hover cursor-pointer" onClick={() => {
                          form.setValue("content", prompt + "\n\n");
                          setIsDialogOpen(true);
                        }}>
                          <CardContent className="p-4">
                            <div className="flex items-start space-x-3">
                              <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center flex-shrink-0">
                                <span className="text-sm font-medium">{index + 1}</span>
                              </div>
                              <p className="text-sm">{prompt}</p>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Journal Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  📊 Journal Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center p-4 bg-blue-400/10 rounded-lg">
                    <div className="text-2xl font-bold text-blue-400 mb-1">
                      {entries.length}
                    </div>
                    <div className="text-sm text-muted-foreground">Total Entries</div>
                  </div>

                  <div className="text-center p-4 bg-green-400/10 rounded-lg">
                    <div className="text-2xl font-bold text-green-400 mb-1">
                      {entries.filter(e => e.date >= format(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), "yyyy-MM-dd")).length}
                    </div>
                    <div className="text-sm text-muted-foreground">This Week</div>
                  </div>

                  <div className="text-center p-4 bg-purple-400/10 rounded-lg">
                    <div className="text-2xl font-bold text-purple-400 mb-1">
                      {new Set(entries.flatMap(e => e.tags || [])).size}
                    </div>
                    <div className="text-sm text-muted-foreground">Unique Tags</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Moods */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  😊 Recent Moods
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {entries.slice(0, 5).map((entry) => (
                    <div key={entry.id} className="flex items-center justify-between">
                      <span className="text-sm">{format(new Date(entry.date), "MMM d")}</span>
                      <div className="flex items-center space-x-2">
                        <span>{getMoodIcon(entry.mood || "neutral")}</span>
                        <span className={`text-xs ${getMoodColor(entry.mood || "neutral")}`}>
                          {moodOptions.find(m => m.value === entry.mood)?.label || "Neutral"}
                        </span>
                      </div>
                    </div>
                  ))}
                  {entries.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      Start journaling to track your moods
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Popular Tags */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  🏷️ Popular Tags
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {Array.from(new Set(entries.flatMap(e => e.tags || [])))
                    .slice(0, 10)
                    .map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  {entries.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center w-full py-4">
                      Tags will appear as you journal
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

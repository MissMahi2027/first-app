import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, Calendar, Users, Target, Star, Clock, ChevronRight } from "lucide-react";

interface Challenge {
  id: string;
  title: string;
  description: string;
  category: string;
  duration: string;
  participants: number;
  difficulty: "easy" | "medium" | "hard";
  reward: string;
  progress?: number;
  isJoined?: boolean;
  startDate: string;
  endDate: string;
}

const challenges: Challenge[] = [
  {
    id: "30-day-reading",
    title: "30-Day Reading Challenge",
    description: "Read for at least 30 minutes every day for 30 days. Build a consistent reading habit.",
    category: "Learning",
    duration: "30 days",
    participants: 1247,
    difficulty: "easy",
    reward: "Reading Master Badge + 500 points",
    progress: 65,
    isJoined: true,
    startDate: "2024-01-01",
    endDate: "2024-01-30",
  },
  {
    id: "fitness-streak",
    title: "7-Day Fitness Streak",
    description: "Complete at least 20 minutes of physical activity every day for a week.",
    category: "Health",
    duration: "7 days",
    participants: 892,
    difficulty: "medium",
    reward: "Fitness Warrior Badge + 300 points",
    startDate: "2024-01-15",
    endDate: "2024-01-21",
  },
  {
    id: "digital-detox",
    title: "Weekend Digital Detox",
    description: "Stay off social media and unnecessary screen time for an entire weekend.",
    category: "Mindfulness",
    duration: "2 days",
    participants: 634,
    difficulty: "hard",
    reward: "Mindful Master Badge + 400 points",
    startDate: "2024-01-20",
    endDate: "2024-01-21",
  },
  {
    id: "gratitude-journal",
    title: "14-Day Gratitude Journal",
    description: "Write down 3 things you're grateful for every day for two weeks.",
    category: "Mindfulness",
    duration: "14 days",
    participants: 1156,
    difficulty: "easy",
    reward: "Grateful Heart Badge + 250 points",
    startDate: "2024-01-10",
    endDate: "2024-01-23",
  },
  {
    id: "skill-building",
    title: "Learn Something New",
    description: "Dedicate 1 hour daily to learning a new skill for 21 days.",
    category: "Learning",
    duration: "21 days",
    participants: 723,
    difficulty: "medium",
    reward: "Skill Builder Badge + 600 points",
    startDate: "2024-01-08",
    endDate: "2024-01-28",
  },
];

const categories = ["All", "Learning", "Health", "Mindfulness", "Social", "Creativity"];

export default function Challenges() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [activeTab, setActiveTab] = useState("available");

  const filteredChallenges = challenges.filter(challenge => 
    selectedCategory === "All" || challenge.category === selectedCategory
  );

  const activeChallenges = filteredChallenges.filter(c => c.isJoined);
  const availableChallenges = filteredChallenges.filter(c => !c.isJoined);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy": return "text-green-400 border-green-400";
      case "medium": return "text-yellow-400 border-yellow-400";
      case "hard": return "text-red-400 border-red-400";
      default: return "text-gray-400 border-gray-400";
    }
  };

  const getDifficultyBg = (difficulty: string) => {
    switch (difficulty) {
      case "easy": return "bg-green-400/10";
      case "medium": return "bg-yellow-400/10";
      case "hard": return "bg-red-400/10";
      default: return "bg-gray-400/10";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Growth Challenges 🏆</h1>
          <p className="text-muted-foreground mt-2">
            Join challenges, build habits, and grow with the community.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Trophy className="w-8 h-8 text-yellow-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">12</p>
                  <p className="text-sm text-muted-foreground">Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Target className="w-8 h-8 text-blue-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">3</p>
                  <p className="text-sm text-muted-foreground">Active</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Star className="w-8 h-8 text-purple-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">2,450</p>
                  <p className="text-sm text-muted-foreground">Points Earned</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="w-8 h-8 text-green-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">47</p>
                  <p className="text-sm text-muted-foreground">Day Streak</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Category Filter */}
        <Card className="mb-8">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 overflow-x-auto">
              <span className="text-sm font-medium flex-shrink-0">Categories:</span>
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="flex-shrink-0"
                >
                  {category}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Challenge Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="available">Available</TabsTrigger>
            <TabsTrigger value="active">My Active ({activeChallenges.length})</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value="available" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {availableChallenges.map((challenge) => (
                <Card key={challenge.id} className="card-hover">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg mb-1">{challenge.title}</h3>
                          <p className="text-sm text-muted-foreground mb-3">{challenge.description}</p>
                        </div>
                        <Badge variant="outline" className={getDifficultyColor(challenge.difficulty)}>
                          {challenge.difficulty}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2 text-muted-foreground" />
                          <span>{challenge.duration}</span>
                        </div>
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-2 text-muted-foreground" />
                          <span>{challenge.participants} joined</span>
                        </div>
                      </div>

                      <div className="p-3 bg-secondary/20 rounded-lg">
                        <div className="flex items-center mb-1">
                          <Trophy className="w-4 h-4 mr-2 text-yellow-400" />
                          <span className="text-sm font-medium">Reward</span>
                        </div>
                        <p className="text-sm text-muted-foreground">{challenge.reward}</p>
                      </div>

                      <Button className="w-full">
                        Join Challenge
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="active" className="space-y-6">
            <div className="space-y-6">
              {activeChallenges.map((challenge) => (
                <Card key={challenge.id} className="card-hover">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg mb-1">{challenge.title}</h3>
                          <p className="text-sm text-muted-foreground mb-3">{challenge.description}</p>
                        </div>
                        <Badge variant="outline" className="text-green-400 border-green-400">
                          Active
                        </Badge>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{challenge.progress}%</span>
                        </div>
                        <ProgressBar value={challenge.progress} className="h-2" />
                      </div>

                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2 text-muted-foreground" />
                          <span>{challenge.duration}</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-2 text-muted-foreground" />
                          <span>5 days left</span>
                        </div>
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-2 text-muted-foreground" />
                          <span>{challenge.participants} joined</span>
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button variant="outline" className="flex-1">
                          View Details
                        </Button>
                        <Button className="flex-1">
                          Log Progress
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="completed" className="space-y-6">
            <div className="text-center py-12">
              <Trophy className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Complete Your First Challenge!</h3>
              <p className="text-muted-foreground mb-6">
                Join an active challenge to start earning badges and building healthy habits.
              </p>
              <Button onClick={() => setActiveTab("available")}>
                Browse Available Challenges
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
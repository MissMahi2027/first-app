import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, TrendingUp, BarChart3, Smile } from "lucide-react";
import { cn } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import type { MoodEntry, InsertMoodEntry } from "@shared/schema";

const moodOptions = [
  { emoji: "😄", label: "Amazing", intensity: 5, color: "bg-green-500" },
  { emoji: "😊", label: "Great", intensity: 4, color: "bg-green-400" },
  { emoji: "🙂", label: "Good", intensity: 3, color: "bg-yellow-400" },
  { emoji: "😐", label: "Okay", intensity: 2, color: "bg-orange-400" },
  { emoji: "😔", label: "Not Great", intensity: 1, color: "bg-red-400" },
];

export default function MoodTracker() {
  const queryClient = useQueryClient();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedMood, setSelectedMood] = useState<typeof moodOptions[0] | null>(null);
  const [notes, setNotes] = useState("");
  const [showCalendar, setShowCalendar] = useState(false);

  const dateString = format(selectedDate, "yyyy-MM-dd");

  // Fetch mood entries
  const { data: moodEntries = [], isLoading } = useQuery<MoodEntry[]>({
    queryKey: ["/api/mood-entries"],
  });

  // Fetch mood entry for selected date
  const { data: todayMood } = useQuery<MoodEntry>({
    queryKey: ["/api/mood-entries", dateString],
    retry: false,
  });

  // Create mood entry mutation
  const createMoodMutation = useMutation({
    mutationFn: async (data: InsertMoodEntry) => {
      return await apiRequest("/api/mood-entries", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mood-entries"] });
      setSelectedMood(null);
      setNotes("");
    },
  });

  // Update mood entry mutation
  const updateMoodMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertMoodEntry> }) => {
      return await apiRequest(`/api/mood-entries/${id}`, "PUT", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mood-entries"] });
      setSelectedMood(null);
      setNotes("");
    },
  });

  // Set existing mood data when date changes
  useEffect(() => {
    if (todayMood) {
      const mood = moodOptions.find(m => m.emoji === todayMood.emoji && m.label === todayMood.moodLabel);
      setSelectedMood(mood || null);
      setNotes(todayMood.notes || "");
    } else {
      setSelectedMood(null);
      setNotes("");
    }
  }, [todayMood]);

  const handleSaveMood = () => {
    if (!selectedMood) return;

    const moodData = {
      date: dateString,
      userId: 1, // Current user ID
      emoji: selectedMood.emoji,
      moodLabel: selectedMood.label,
      intensity: selectedMood.intensity,
      notes: notes.trim() || null,
    };

    if (todayMood) {
      updateMoodMutation.mutate({ id: todayMood.id, data: moodData });
    } else {
      createMoodMutation.mutate(moodData);
    }
  };

  const recentMoods = moodEntries.slice(0, 7);
  const averageMood = moodEntries.length > 0 
    ? (moodEntries.reduce((sum, entry) => sum + entry.intensity, 0) / moodEntries.length).toFixed(1)
    : "0";

  const getMoodStats = () => {
    if (moodEntries.length === 0) return { streak: 0, totalEntries: 0 };
    
    // Calculate current streak
    let streak = 0;
    const sortedEntries = [...moodEntries].sort((a, b) => b.date.localeCompare(a.date));
    const today = format(new Date(), "yyyy-MM-dd");
    
    for (let i = 0; i < sortedEntries.length; i++) {
      const entryDate = sortedEntries[i].date;
      const expectedDate = format(new Date(Date.now() - i * 24 * 60 * 60 * 1000), "yyyy-MM-dd");
      
      if (entryDate === expectedDate) {
        streak++;
      } else {
        break;
      }
    }

    return { streak, totalEntries: moodEntries.length };
  };

  const stats = getMoodStats();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-white/10 rounded-lg w-64"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="h-32 bg-white/10 rounded-xl"></div>
              <div className="h-32 bg-white/10 rounded-xl"></div>
              <div className="h-32 bg-white/10 rounded-xl"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2">
            <Smile className="h-8 w-8 text-purple-400" />
            <h1 className="text-3xl font-bold text-white">Mood Tracker</h1>
          </div>
          <p className="text-gray-300">Track your daily emotions and build mindful habits</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-500/20 rounded-lg">
                  <TrendingUp className="h-6 w-6 text-green-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{stats.streak}</p>
                  <p className="text-sm text-gray-400">Day Streak</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500/20 rounded-lg">
                  <BarChart3 className="h-6 w-6 text-blue-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{averageMood}</p>
                  <p className="text-sm text-gray-400">Average Mood</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-500/20 rounded-lg">
                  <Smile className="h-6 w-6 text-purple-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{stats.totalEntries}</p>
                  <p className="text-sm text-gray-400">Total Entries</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Mood Entry Card */}
        <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2">
                How are you feeling?
              </CardTitle>
              
              <Popover open={showCalendar} onOpenChange={setShowCalendar}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-[200px] justify-start text-left font-normal bg-white/5 border-white/20 text-white hover:bg-white/10",
                      !selectedDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-slate-800 border-white/20">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => {
                      if (date) {
                        setSelectedDate(date);
                        setShowCalendar(false);
                      }
                    }}
                    initialFocus
                    className="text-white"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Mood Selection */}
            <div>
              <p className="text-gray-300 mb-4">Select your mood:</p>
              <div className="grid grid-cols-5 gap-3">
                {moodOptions.map((mood) => (
                  <Button
                    key={mood.label}
                    variant="outline"
                    className={cn(
                      "h-20 flex-col gap-2 bg-white/5 border-white/20 hover:bg-white/10 transition-all duration-200",
                      selectedMood?.label === mood.label && "ring-2 ring-purple-400 bg-purple-500/20"
                    )}
                    onClick={() => setSelectedMood(mood)}
                  >
                    <span className="text-2xl">{mood.emoji}</span>
                    <span className="text-xs text-gray-300">{mood.label}</span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Notes */}
            {selectedMood && (
              <div className="space-y-3">
                <p className="text-gray-300">Add notes (optional):</p>
                <Textarea
                  placeholder="What's on your mind? How are you feeling today?"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="bg-white/5 border-white/20 text-white placeholder:text-gray-400 resize-none"
                  rows={3}
                />
              </div>
            )}

            {/* Save Button */}
            {selectedMood && (
              <Button
                onClick={handleSaveMood}
                disabled={createMoodMutation.isPending || updateMoodMutation.isPending}
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-medium py-3"
              >
                {createMoodMutation.isPending || updateMoodMutation.isPending
                  ? "Saving..."
                  : todayMood
                  ? "Update Mood"
                  : "Save Mood"
                }
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Recent Moods */}
        {recentMoods.length > 0 && (
          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white">Recent Moods</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentMoods.map((entry) => (
                  <div
                    key={entry.id}
                    className="flex items-center justify-between p-3 bg-white/5 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{entry.emoji}</span>
                      <div>
                        <p className="text-white font-medium">{entry.moodLabel}</p>
                        <p className="text-gray-400 text-sm">{format(new Date(entry.date), "MMM d, yyyy")}</p>
                      </div>
                    </div>
                    <Badge
                      variant="secondary"
                      className={cn(
                        "text-white",
                        entry.intensity >= 4 && "bg-green-500/20 text-green-300",
                        entry.intensity === 3 && "bg-yellow-500/20 text-yellow-300",
                        entry.intensity <= 2 && "bg-red-500/20 text-red-300"
                      )}
                    >
                      {entry.intensity}/5
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
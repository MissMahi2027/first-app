import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Play, Pause, Square, Clock, Target, TrendingUp, Calendar, Plus, CheckCircle, Smartphone, Shield, Youtube, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PomodoroSession {
  id: string;
  type: "work" | "break" | "longBreak";
  duration: number;
  completed: boolean;
  date: string;
}

interface Task {
  id: string;
  title: string;
  category: string;
  priority: "low" | "medium" | "high";
  estimatedPomodoros: number;
  completedPomodoros: number;
  isCompleted: boolean;
  dueDate?: string;
}

interface TimeBlock {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  category: string;
  color: string;
}

interface ScreenTimeEntry {
  id: string;
  appName: string;
  timeUsed: string;
  timestamp: string;
}

const initialTasks: Task[] = [
  {
    id: "1",
    title: "Complete Math Homework",
    category: "Study",
    priority: "high",
    estimatedPomodoros: 3,
    completedPomodoros: 1,
    isCompleted: false,
    dueDate: "2024-01-22"
  },
  {
    id: "2",
    title: "Read History Chapter",
    category: "Study",
    priority: "medium",
    estimatedPomodoros: 2,
    completedPomodoros: 0,
    isCompleted: false,
    dueDate: "2024-01-23"
  },
  {
    id: "3",
    title: "Exercise for 30 minutes",
    category: "Health",
    priority: "medium",
    estimatedPomodoros: 1,
    completedPomodoros: 1,
    isCompleted: true
  }
];

const timeBlocks: TimeBlock[] = [
  { id: "1", title: "Morning Study", startTime: "09:00", endTime: "11:00", category: "Study", color: "bg-blue-400" },
  { id: "2", title: "Lunch Break", startTime: "12:00", endTime: "13:00", category: "Break", color: "bg-green-400" },
  { id: "3", title: "Project Work", startTime: "14:00", endTime: "16:00", category: "Work", color: "bg-purple-400" },
  { id: "4", title: "Exercise", startTime: "17:00", endTime: "18:00", category: "Health", color: "bg-orange-400" }
];

export default function Productivity() {
  const { toast } = useToast();
  
  // Pomodoro states
  const [isRunning, setIsRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [currentSession, setCurrentSession] = useState<"work" | "break" | "longBreak">("work");
  const [sessionCount, setSessionCount] = useState(0);
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Screen Time states
  const [screenTimeEntries, setScreenTimeEntries] = useState<ScreenTimeEntry[]>([]);
  const [newAppName, setNewAppName] = useState("");
  const [newTimeUsed, setNewTimeUsed] = useState("");

  // YouTube Summarizer states
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [summaryResult, setSummaryResult] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [summaryError, setSummaryError] = useState("");

  const settings = {
    workTime: 25,
    breakTime: 5,
    longBreakTime: 15,
    sessionsUntilLongBreak: 4
  };

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(timeLeft => timeLeft - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      // Session completed
      setIsRunning(false);
      handleSessionComplete();
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeLeft]);

  const handleSessionComplete = () => {
    if (currentSession === "work") {
      const newCount = sessionCount + 1;
      setSessionCount(newCount);
      
      if (newCount % settings.sessionsUntilLongBreak === 0) {
        setCurrentSession("longBreak");
        setTimeLeft(settings.longBreakTime * 60);
      } else {
        setCurrentSession("break");
        setTimeLeft(settings.breakTime * 60);
      }
    } else {
      setCurrentSession("work");
      setTimeLeft(settings.workTime * 60);
    }
  };

  const startTimer = () => setIsRunning(true);
  const pauseTimer = () => setIsRunning(false);
  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(settings.workTime * 60);
    setCurrentSession("work");
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const addTask = () => {
    if (newTaskTitle.trim()) {
      const newTask: Task = {
        id: Date.now().toString(),
        title: newTaskTitle,
        category: "General",
        priority: "medium",
        estimatedPomodoros: 1,
        completedPomodoros: 0,
        isCompleted: false
      };
      setTasks([...tasks, newTask]);
      setNewTaskTitle("");
      setIsDialogOpen(false);
    }
  };

  const toggleTask = (taskId: string) => {
    setTasks(tasks.map(task => 
      task.id === taskId 
        ? { ...task, isCompleted: !task.isCompleted }
        : task
    ));
  };

  // Screen Time Functions
  const addScreenTimeEntry = () => {
    if (!newAppName.trim() || !newTimeUsed.trim()) {
      toast({
        title: "Error",
        description: "Please fill in both app name and time used",
        variant: "destructive",
      });
      return;
    }

    const newEntry: ScreenTimeEntry = {
      id: Date.now().toString(),
      appName: newAppName.trim(),
      timeUsed: newTimeUsed.trim(),
      timestamp: new Date().toISOString(),
    };

    setScreenTimeEntries([...screenTimeEntries, newEntry]);
    setNewAppName("");
    setNewTimeUsed("");
    
    toast({
      title: "Entry Added",
      description: `${newEntry.appName} screen time tracked`,
    });
  };

  const deleteScreenTimeEntry = (entryId: string) => {
    setScreenTimeEntries(screenTimeEntries.filter(entry => entry.id !== entryId));
    toast({
      title: "Entry Deleted",
      description: "Screen time entry removed",
    });
  };

  // YouTube Summarizer Functions
  const summarizeVideo = async () => {
    if (!youtubeUrl.trim()) {
      toast({
        title: "Error",
        description: "Please enter a YouTube URL",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setSummaryError("");
    setSummaryResult("");

    try {
      const response = await apiRequest("POST", "/api/summarize-youtube", {
        youtube_url: youtubeUrl,
      });

      if (response.success) {
        setSummaryResult(response.summary);
        toast({
          title: "Summary Generated",
          description: "YouTube video has been summarized successfully",
        });
      } else {
        setSummaryError(response.error || "Failed to generate summary");
        toast({
          title: "Error",
          description: response.error || "Failed to generate summary",
          variant: "destructive",
        });
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Network error occurred";
      setSummaryError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "text-red-400 border-red-400";
      case "medium": return "text-yellow-400 border-yellow-400";
      case "low": return "text-green-400 border-green-400";
      default: return "text-gray-400 border-gray-400";
    }
  };

  const completedTasks = tasks.filter(t => t.isCompleted).length;
  const totalPomodoros = tasks.reduce((sum, task) => sum + task.completedPomodoros, 0);
  const focusTime = totalPomodoros * 25; // minutes

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Productivity Hub ⚡</h1>
          <p className="text-muted-foreground mt-2">
            Boost your focus with Pomodoro timer, task management, and time blocking.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Clock className="w-8 h-8 text-blue-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{focusTime}</p>
                  <p className="text-sm text-muted-foreground">Focus Minutes</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Target className="w-8 h-8 text-green-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{completedTasks}</p>
                  <p className="text-sm text-muted-foreground">Tasks Done</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <TrendingUp className="w-8 h-8 text-purple-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{sessionCount}</p>
                  <p className="text-sm text-muted-foreground">Sessions Today</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Calendar className="w-8 h-8 text-orange-400 mr-3" />
                <div>
                  <p className="text-2xl font-bold">7</p>
                  <p className="text-sm text-muted-foreground">Day Streak</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="pomodoro" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="pomodoro">Pomodoro Timer</TabsTrigger>
            <TabsTrigger value="tasks">Task Manager</TabsTrigger>
            <TabsTrigger value="schedule">Time Blocks</TabsTrigger>
            <TabsTrigger value="screentime">Screen Time</TabsTrigger>
            <TabsTrigger value="blocker">Blocker Tips</TabsTrigger>
            <TabsTrigger value="summarizer">Summarizer</TabsTrigger>
          </TabsList>

          <TabsContent value="pomodoro" className="space-y-6">
            <div className="max-w-2xl mx-auto">
              <Card>
                <CardContent className="p-8 text-center">
                  <div className="mb-6">
                    <Badge variant="outline" className="mb-4 text-lg px-4 py-2">
                      {currentSession === "work" ? "🍅 Focus Time" : 
                       currentSession === "break" ? "☕ Short Break" : 
                       "🌟 Long Break"}
                    </Badge>
                    <div className="text-6xl font-mono font-bold mb-4">
                      {formatTime(timeLeft)}
                    </div>
                    <ProgressBar 
                      value={((currentSession === "work" ? settings.workTime * 60 : 
                               currentSession === "break" ? settings.breakTime * 60 : 
                               settings.longBreakTime * 60) - timeLeft) / 
                              (currentSession === "work" ? settings.workTime * 60 : 
                               currentSession === "break" ? settings.breakTime * 60 : 
                               settings.longBreakTime * 60) * 100} 
                      className="h-3 mb-6" 
                    />
                  </div>

                  <div className="flex justify-center space-x-4 mb-6">
                    {!isRunning ? (
                      <Button onClick={startTimer} size="lg" className="px-8">
                        <Play className="w-5 h-5 mr-2" />
                        Start
                      </Button>
                    ) : (
                      <Button onClick={pauseTimer} size="lg" variant="outline" className="px-8">
                        <Pause className="w-5 h-5 mr-2" />
                        Pause
                      </Button>
                    )}
                    <Button onClick={resetTimer} size="lg" variant="outline" className="px-8">
                      <Square className="w-5 h-5 mr-2" />
                      Reset
                    </Button>
                  </div>

                  <div className="text-sm text-muted-foreground">
                    Session {sessionCount + 1} • Next: {sessionCount % settings.sessionsUntilLongBreak === settings.sessionsUntilLongBreak - 1 ? "Long Break" : "Short Break"}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tasks" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Today's Tasks</h2>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Task
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Task</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Input
                      placeholder="Enter task title..."
                      value={newTaskTitle}
                      onChange={(e) => setNewTaskTitle(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addTask()}
                    />
                    <div className="flex space-x-2">
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="flex-1">
                        Cancel
                      </Button>
                      <Button onClick={addTask} className="flex-1">
                        Add Task
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="space-y-4">
              {tasks.map((task) => (
                <Card key={task.id} className={`cursor-pointer transition-colors ${task.isCompleted ? 'opacity-60' : ''}`}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3 flex-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleTask(task.id)}
                          className="p-1"
                        >
                          <CheckCircle className={`w-5 h-5 ${task.isCompleted ? 'text-green-400' : 'text-muted-foreground'}`} />
                        </Button>
                        
                        <div className="flex-1">
                          <h3 className={`font-medium ${task.isCompleted ? 'line-through text-muted-foreground' : ''}`}>
                            {task.title}
                          </h3>
                          <div className="flex items-center space-x-2 mt-1">
                            <Badge variant="outline" className={getPriorityColor(task.priority)}>
                              {task.priority}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              {task.completedPomodoros}/{task.estimatedPomodoros} pomodoros
                            </span>
                            {task.dueDate && (
                              <span className="text-sm text-muted-foreground">
                                Due: {new Date(task.dueDate).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <ProgressBar 
                          value={(task.completedPomodoros / task.estimatedPomodoros) * 100} 
                          className="w-20 h-2" 
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="schedule" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Today's Schedule</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {timeBlocks.map((block) => (
                    <div key={block.id} className="flex items-center space-x-4 p-3 border border-border rounded-lg">
                      <div className={`w-4 h-4 rounded-full ${block.color}`}></div>
                      <div className="flex-1">
                        <h4 className="font-medium">{block.title}</h4>
                        <p className="text-sm text-muted-foreground">{block.category}</p>
                      </div>
                      <div className="text-sm font-medium">
                        {block.startTime} - {block.endTime}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="screentime" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Smartphone className="w-5 h-5 mr-2" />
                  Screen Time Tracker
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="App Name (e.g., Instagram, TikTok)"
                      value={newAppName}
                      onChange={(e) => setNewAppName(e.target.value)}
                    />
                    <Input
                      placeholder="Time Used (e.g., 2 hours, 45 minutes)"
                      value={newTimeUsed}
                      onChange={(e) => setNewTimeUsed(e.target.value)}
                    />
                  </div>
                  <Button 
                    onClick={addScreenTimeEntry}
                    className="w-full md:w-auto"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Entry
                  </Button>
                </div>

                <div className="mt-6 space-y-3">
                  {screenTimeEntries.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                      <Smartphone className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No screen time entries yet.</p>
                      <p className="text-sm">Add your first entry above to start tracking!</p>
                    </div>
                  ) : (
                    screenTimeEntries.map((entry) => (
                      <Card key={entry.id} className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h4 className="font-medium">{entry.appName}</h4>
                            <p className="text-sm text-muted-foreground">{entry.timeUsed}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(entry.timestamp).toLocaleString()}
                            </p>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => deleteScreenTimeEntry(entry.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </Card>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="blocker" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="w-5 h-5 mr-2" />
                  Reels & Shorts Blocker Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-6">
                  Practical strategies to avoid endless scrolling and stay focused:
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="p-4 bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
                    <h3 className="font-semibold text-green-800 dark:text-green-200 mb-2">
                      🖥️ Use Desktop Mode
                    </h3>
                    <p className="text-sm text-green-700 dark:text-green-300">
                      Switch to desktop versions of Instagram and YouTube to avoid mobile-optimized endless feeds.
                    </p>
                  </Card>

                  <Card className="p-4 bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
                    <h3 className="font-semibold text-blue-800 dark:text-blue-200 mb-2">
                      🔌 Browser Extensions
                    </h3>
                    <p className="text-sm text-blue-700 dark:text-blue-300">
                      Install "Unhook" for YouTube or "Social Media Blocker" extensions to hide Reels and Shorts.
                    </p>
                  </Card>

                  <Card className="p-4 bg-purple-50 dark:bg-purple-950 border-purple-200 dark:border-purple-800">
                    <h3 className="font-semibold text-purple-800 dark:text-purple-200 mb-2">
                      ⏰ Set Time Limits
                    </h3>
                    <p className="text-sm text-purple-700 dark:text-purple-300">
                      Use Screen Time (iOS) or Digital Wellbeing (Android) to set daily app usage limits.
                    </p>
                  </Card>

                  <Card className="p-4 bg-orange-50 dark:bg-orange-950 border-orange-200 dark:border-orange-800">
                    <h3 className="font-semibold text-orange-800 dark:text-orange-200 mb-2">
                      📱 App Alternatives
                    </h3>
                    <p className="text-sm text-orange-700 dark:text-orange-300">
                      Use web versions or alternative apps that don't have addictive short-form content.
                    </p>
                  </Card>

                  <Card className="p-4 bg-indigo-50 dark:bg-indigo-950 border-indigo-200 dark:border-indigo-800">
                    <h3 className="font-semibold text-indigo-800 dark:text-indigo-200 mb-2">
                      🎯 Intentional Usage
                    </h3>
                    <p className="text-sm text-indigo-700 dark:text-indigo-300">
                      Set a specific purpose before opening apps: "I want to check messages" instead of mindless browsing.
                    </p>
                  </Card>

                  <Card className="p-4 bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800">
                    <h3 className="font-semibold text-red-800 dark:text-red-200 mb-2">
                      🔔 Turn Off Notifications
                    </h3>
                    <p className="text-sm text-red-700 dark:text-red-300">
                      Disable push notifications for social media apps to reduce impulsive checking.
                    </p>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="summarizer" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Youtube className="w-5 h-5 mr-2" />
                  YouTube Summarizer
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Input
                    type="url"
                    placeholder="Paste YouTube URL here (e.g., https://www.youtube.com/watch?v=...)"
                    value={youtubeUrl}
                    onChange={(e) => setYoutubeUrl(e.target.value)}
                  />
                  
                  <Button 
                    onClick={summarizeVideo}
                    disabled={isLoading}
                    className="w-full md:w-auto"
                  >
                    {isLoading ? (
                      <>
                        <div className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Generating Summary...
                      </>
                    ) : (
                      <>
                        <Youtube className="w-4 h-4 mr-2" />
                        Summarize Video
                      </>
                    )}
                  </Button>
                </div>

                {summaryError && (
                  <Card className="mt-4 p-4 bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800">
                    <h3 className="font-semibold text-red-800 dark:text-red-200 mb-2">
                      ❌ Error
                    </h3>
                    <p className="text-sm text-red-700 dark:text-red-300">
                      {summaryError}
                    </p>
                  </Card>
                )}

                {summaryResult && (
                  <Card className="mt-4 p-4 bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
                    <h3 className="font-semibold text-green-800 dark:text-green-200 mb-2">
                      📋 Video Summary
                    </h3>
                    <div className="text-sm text-green-700 dark:text-green-300 whitespace-pre-line">
                      {summaryResult}
                    </div>
                  </Card>
                )}

                {!summaryResult && !summaryError && !isLoading && (
                  <div className="text-center text-muted-foreground py-8">
                    <Youtube className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Enter a YouTube URL above to generate an AI summary.</p>
                    <p className="text-sm">Get key insights without watching the entire video!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}